-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: zugferd
-- ------------------------------------------------------
-- Server version	10.11.6-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tfb_accounts`
--

DROP TABLE IF EXISTS `tfb_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(191) NOT NULL DEFAULT 'bank',
  `name` varchar(191) NOT NULL,
  `number` varchar(191) NOT NULL,
  `currency_code` varchar(191) NOT NULL,
  `opening_balance` double(15,4) NOT NULL DEFAULT 0.0000,
  `bank_name` varchar(191) DEFAULT NULL,
  `bank_phone` varchar(191) DEFAULT NULL,
  `bank_address` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_accounts_company_id_index` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_accounts`
--

LOCK TABLES `tfb_accounts` WRITE;
/*!40000 ALTER TABLE `tfb_accounts` DISABLE KEYS */;
INSERT INTO `tfb_accounts` VALUES
(1,1,'bank','Bargeld','1','EUR',0.0000,'Bargeld',NULL,NULL,1,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 13:23:56',NULL);
/*!40000 ALTER TABLE `tfb_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_categories`
--

DROP TABLE IF EXISTS `tfb_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `type` varchar(191) NOT NULL,
  `color` varchar(191) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_categories_company_id_index` (`company_id`),
  KEY `tfb_categories_parent_id_foreign` (`parent_id`),
  CONSTRAINT `tfb_categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `tfb_categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_categories`
--

LOCK TABLES `tfb_categories` WRITE;
/*!40000 ALTER TABLE `tfb_categories` DISABLE KEYS */;
INSERT INTO `tfb_categories` VALUES
(1,1,'Transfer','other','#3c3f72',1,NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(2,1,'Einzahlung','income','#efad32',1,NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(3,1,'Vertrieb','income','#6da252',1,NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(4,1,'Andere','expense','#e5e5e5',1,NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(5,1,'Allgemein','item','#328aef',1,NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL);
/*!40000 ALTER TABLE `tfb_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_companies`
--

DROP TABLE IF EXISTS `tfb_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_companies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `domain` varchar(191) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_companies`
--

LOCK TABLES `tfb_companies` WRITE;
/*!40000 ALTER TABLE `tfb_companies` DISABLE KEYS */;
INSERT INTO `tfb_companies` VALUES
(1,'',1,'core::ui',NULL,'2024-10-02 11:18:49','2024-10-02 11:18:49',NULL);
/*!40000 ALTER TABLE `tfb_companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_contact_persons`
--

DROP TABLE IF EXISTS `tfb_contact_persons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_contact_persons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `type` varchar(191) NOT NULL,
  `contact_id` int(10) unsigned NOT NULL,
  `name` varchar(191) DEFAULT NULL,
  `email` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_contact_persons_company_id_index` (`company_id`),
  KEY `tfb_contact_persons_type_index` (`type`),
  KEY `tfb_contact_persons_contact_id_index` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_contact_persons`
--

LOCK TABLES `tfb_contact_persons` WRITE;
/*!40000 ALTER TABLE `tfb_contact_persons` DISABLE KEYS */;
/*!40000 ALTER TABLE `tfb_contact_persons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_contacts`
--

DROP TABLE IF EXISTS `tfb_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tax_number` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `zip_code` varchar(191) DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `country` varchar(191) DEFAULT NULL,
  `website` varchar(191) DEFAULT NULL,
  `currency_code` varchar(191) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `reference` varchar(191) DEFAULT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfb_contacts_company_id_type_email_deleted_at_unique` (`company_id`,`type`,`email`,`deleted_at`),
  KEY `tfb_contacts_company_id_type_index` (`company_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_contacts`
--

LOCK TABLES `tfb_contacts` WRITE;
/*!40000 ALTER TABLE `tfb_contacts` DISABLE KEYS */;
INSERT INTO `tfb_contacts` VALUES
(1,1,'customer','Flyermeyer','matthias@mk-pages.com',NULL,'221/345/3344','018281925','Obere Eisenstraße 18','Lauf an der Pegnitz','91207','Bayern','DE',NULL,'EUR',1,NULL,'core::ui',1,'2024-12-17 22:45:45','2024-12-18 18:41:41',NULL);
/*!40000 ALTER TABLE `tfb_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_currencies`
--

DROP TABLE IF EXISTS `tfb_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_currencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `code` varchar(191) NOT NULL,
  `rate` double(15,8) NOT NULL,
  `precision` varchar(191) DEFAULT NULL,
  `symbol` varchar(191) DEFAULT NULL,
  `symbol_first` int(11) NOT NULL DEFAULT 1,
  `decimal_mark` varchar(191) DEFAULT NULL,
  `thousands_separator` varchar(191) DEFAULT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT 1,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfb_currencies_company_id_code_deleted_at_unique` (`company_id`,`code`,`deleted_at`),
  KEY `tfb_currencies_company_id_index` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_currencies`
--

LOCK TABLES `tfb_currencies` WRITE;
/*!40000 ALTER TABLE `tfb_currencies` DISABLE KEYS */;
INSERT INTO `tfb_currencies` VALUES
(1,1,'US-Dollar','USD',1.00000000,'2','$',1,'.',',',1,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 13:24:07','2024-10-02 13:24:07'),
(2,1,'Euro','EUR',1.00000000,NULL,NULL,1,NULL,NULL,1,'core::ui',1,'2024-10-02 12:21:06','2024-10-02 12:21:06',NULL);
/*!40000 ALTER TABLE `tfb_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_dashboards`
--

DROP TABLE IF EXISTS `tfb_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_dashboards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_dashboards_company_id_index` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_dashboards`
--

LOCK TABLES `tfb_dashboards` WRITE;
/*!40000 ALTER TABLE `tfb_dashboards` DISABLE KEYS */;
INSERT INTO `tfb_dashboards` VALUES
(1,1,'Dashboard',1,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(3,1,'Dashboard',1,'core::seed',1,'2025-01-02 20:43:19','2025-01-02 20:43:19',NULL);
/*!40000 ALTER TABLE `tfb_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_document_histories`
--

DROP TABLE IF EXISTS `tfb_document_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_document_histories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(191) NOT NULL,
  `document_id` int(10) unsigned NOT NULL,
  `status` varchar(191) NOT NULL,
  `notify` tinyint(1) NOT NULL,
  `description` text DEFAULT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_document_histories_company_id_index` (`company_id`),
  KEY `tfb_document_histories_type_index` (`type`),
  KEY `tfb_document_histories_document_id_index` (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_document_histories`
--

LOCK TABLES `tfb_document_histories` WRITE;
/*!40000 ALTER TABLE `tfb_document_histories` DISABLE KEYS */;
INSERT INTO `tfb_document_histories` VALUES
(1,1,'invoice',1,'draft',0,'INV-00001 hinzugefügt!','core::ui',1,'2024-12-17 22:46:41','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(2,1,'invoice',1,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',1,'2024-12-18 19:16:38','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(3,1,'invoice',1,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',1,'2024-12-18 19:19:58','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(4,1,'invoice',1,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',1,'2024-12-18 19:21:30','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(5,1,'invoice',1,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',1,'2024-12-18 19:53:14','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(6,1,'invoice',1,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',1,'2024-12-18 21:08:44','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(7,1,'invoice',1,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',1,'2024-12-18 21:13:48','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(8,1,'invoice',1,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',1,'2024-12-18 21:28:12','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(9,1,'invoice',1,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',1,'2024-12-18 21:29:57','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(10,1,'invoice',1,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',1,'2024-12-18 21:42:44','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(11,1,'invoice',1,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',1,'2024-12-18 21:54:22','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(12,1,'invoice',1,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',1,'2024-12-18 22:10:22','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(13,1,'invoice',1,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',1,'2024-12-18 22:33:58','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(14,1,'invoice',1,'paid',0,'€238,00 Zahlung','core::ui',1,'2024-12-18 23:34:28','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(15,1,'invoice',2,'draft',0,'INV-00002 hinzugefügt!','core::ui',1,'2024-12-18 23:36:43','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(16,1,'invoice',3,'draft',0,'INV-00003 hinzugefügt!','core::ui',1,'2024-12-19 11:01:17','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(17,1,'invoice',4,'draft',0,'INV-00004 hinzugefügt!','core::ui',1,'2024-12-19 11:32:36','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(18,1,'invoice',5,'draft',0,'INV-00005 hinzugefügt!','core::ui',1,'2024-12-19 12:09:39','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(19,1,'invoice',5,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',1,'2024-12-19 12:18:17','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(20,1,'invoice',5,'paid',0,'€238,00 Zahlung','core::ui',1,'2024-12-19 12:18:57','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(21,1,'invoice',6,'draft',0,'INV-00006 hinzugefügt!','core::ui',1,'2024-12-19 17:27:00','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(22,1,'invoice',7,'draft',0,'INV-00007 hinzugefügt!','core::ui',1,'2024-12-20 16:30:12','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(23,1,'invoice',1,'sent',0,'€238,00 Zahlung gelöscht!','core::ui',3,'2025-01-20 18:58:38','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(24,1,'invoice',5,'sent',0,'€238,00 Zahlung gelöscht!','core::ui',3,'2025-01-20 18:58:38','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(25,1,'invoice',8,'draft',0,'INV-00008 hinzugefügt!','core::ui',3,'2025-01-20 19:04:25','2025-01-20 23:12:48','2025-01-20 23:12:48'),
(26,1,'invoice',9,'draft',0,'INV-00009 hinzugefügt!','core::ui',3,'2025-01-20 19:47:55','2025-01-20 23:11:22','2025-01-20 23:11:22'),
(27,1,'invoice',9,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',3,'2025-01-20 21:28:57','2025-01-20 23:11:22','2025-01-20 23:11:22'),
(28,1,'invoice',9,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',3,'2025-01-20 21:29:26','2025-01-20 23:11:22','2025-01-20 23:11:22'),
(29,1,'invoice',9,'sent',0,'Rechnung wurde per E-Mail versendet!','core::ui',3,'2025-01-20 21:30:07','2025-01-20 23:11:22','2025-01-20 23:11:22'),
(30,1,'invoice',9,'viewed',0,'Invoice marked as viewed!','core::ui',NULL,'2025-01-20 22:24:45','2025-01-20 23:11:22','2025-01-20 23:11:22'),
(31,1,'invoice',10,'draft',0,'2025-00001 hinzugefügt!','core::ui',3,'2025-01-20 23:16:02','2025-01-20 23:30:33','2025-01-20 23:30:33');
/*!40000 ALTER TABLE `tfb_document_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_document_item_taxes`
--

DROP TABLE IF EXISTS `tfb_document_item_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_document_item_taxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `type` varchar(191) NOT NULL,
  `document_id` int(10) unsigned NOT NULL,
  `document_item_id` int(10) unsigned NOT NULL,
  `tax_id` int(10) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `amount` double(15,4) NOT NULL DEFAULT 0.0000,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_document_item_taxes_company_id_index` (`company_id`),
  KEY `tfb_document_item_taxes_type_index` (`type`),
  KEY `tfb_document_item_taxes_document_id_index` (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_document_item_taxes`
--

LOCK TABLES `tfb_document_item_taxes` WRITE;
/*!40000 ALTER TABLE `tfb_document_item_taxes` DISABLE KEYS */;
INSERT INTO `tfb_document_item_taxes` VALUES
(2,1,'invoice',1,2,1,'Umsatzsteuer',38.0000,'core::ui',1,'2024-12-18 18:41:54','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(3,1,'invoice',2,3,1,'Umsatzsteuer',38.0000,'core::ui',1,'2024-12-18 23:36:43','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(4,1,'invoice',3,4,1,'Umsatzsteuer',76.0000,'core::ui',1,'2024-12-19 11:01:17','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(5,1,'invoice',3,5,1,'Umsatzsteuer',38.0000,'core::ui',1,'2024-12-19 11:01:17','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(6,1,'invoice',4,6,1,'Umsatzsteuer',38.0000,'core::ui',1,'2024-12-19 11:32:36','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(7,1,'invoice',5,7,1,'Umsatzsteuer',38.0000,'core::ui',1,'2024-12-19 12:09:39','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(8,1,'invoice',7,8,1,'Umsatzsteuer',38.0000,'core::ui',1,'2024-12-20 16:30:12','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(9,1,'invoice',7,9,1,'Umsatzsteuer',38.0000,'core::ui',1,'2024-12-20 16:30:12','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(10,1,'invoice',7,10,1,'Umsatzsteuer',38.0000,'core::ui',1,'2024-12-20 16:30:12','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(11,1,'invoice',8,11,1,'Umsatzsteuer',38.0000,'core::ui',3,'2025-01-20 19:04:25','2025-01-20 23:12:48','2025-01-20 23:12:48'),
(12,1,'invoice',9,12,1,'Umsatzsteuer',38.0000,'core::ui',3,'2025-01-20 19:47:55','2025-01-20 23:11:22','2025-01-20 23:11:22'),
(13,1,'invoice',9,13,1,'Umsatzsteuer',38.0000,'core::ui',3,'2025-01-20 19:47:55','2025-01-20 23:11:22','2025-01-20 23:11:22'),
(14,1,'invoice',10,14,1,'Umsatzsteuer',38.0000,'core::ui',3,'2025-01-20 23:16:02','2025-01-20 23:30:33','2025-01-20 23:30:33');
/*!40000 ALTER TABLE `tfb_document_item_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_document_items`
--

DROP TABLE IF EXISTS `tfb_document_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_document_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `type` varchar(191) NOT NULL,
  `document_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `sku` varchar(191) DEFAULT NULL,
  `quantity` double(7,2) NOT NULL,
  `price` double(15,4) NOT NULL,
  `tax` double(15,4) NOT NULL DEFAULT 0.0000,
  `discount_type` varchar(191) NOT NULL DEFAULT 'normal',
  `discount_rate` double(15,4) NOT NULL DEFAULT 0.0000,
  `total` double(15,4) NOT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_document_items_company_id_index` (`company_id`),
  KEY `tfb_document_items_type_index` (`type`),
  KEY `tfb_document_items_document_id_index` (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_document_items`
--

LOCK TABLES `tfb_document_items` WRITE;
/*!40000 ALTER TABLE `tfb_document_items` DISABLE KEYS */;
INSERT INTO `tfb_document_items` VALUES
(2,1,'invoice',1,1,'Website','Webdesign',NULL,1.00,200.0000,38.0000,'undefined',0.0000,200.0000,'core::ui',1,'2024-12-18 18:41:54','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(3,1,'invoice',2,1,'Website','Webdesign',NULL,1.00,200.0000,38.0000,'undefined',0.0000,200.0000,'core::ui',1,'2024-12-18 23:36:43','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(4,1,'invoice',3,1,'Website','Webdesign',NULL,2.00,200.0000,76.0000,'undefined',0.0000,400.0000,'core::ui',1,'2024-12-19 11:01:17','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(5,1,'invoice',3,1,'Website','Webdesign',NULL,1.00,200.0000,38.0000,'undefined',0.0000,200.0000,'core::ui',1,'2024-12-19 11:01:17','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(6,1,'invoice',4,1,'Website','Webdesign',NULL,1.00,200.0000,38.0000,'undefined',0.0000,200.0000,'core::ui',1,'2024-12-19 11:32:36','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(7,1,'invoice',5,1,'Website','Webdesign',NULL,1.00,200.0000,38.0000,'undefined',0.0000,200.0000,'core::ui',1,'2024-12-19 12:09:39','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(8,1,'invoice',7,1,'Website','Webdesign',NULL,1.00,200.0000,38.0000,'undefined',0.0000,200.0000,'core::ui',1,'2024-12-20 16:30:12','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(9,1,'invoice',7,1,'Website','Webdesign',NULL,1.00,200.0000,38.0000,'undefined',0.0000,200.0000,'core::ui',1,'2024-12-20 16:30:12','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(10,1,'invoice',7,1,'Website','Webdesign',NULL,1.00,200.0000,38.0000,'undefined',0.0000,200.0000,'core::ui',1,'2024-12-20 16:30:12','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(11,1,'invoice',8,1,'Website','Webdesign',NULL,1.00,200.0000,38.0000,'undefined',0.0000,200.0000,'core::ui',3,'2025-01-20 19:04:25','2025-01-20 23:12:48','2025-01-20 23:12:48'),
(12,1,'invoice',9,1,'Website','Webdesign',NULL,1.00,200.0000,38.0000,'undefined',0.0000,200.0000,'core::ui',3,'2025-01-20 19:47:55','2025-01-20 23:11:22','2025-01-20 23:11:22'),
(13,1,'invoice',9,1,'Website','Webdesign',NULL,1.00,200.0000,38.0000,'undefined',0.0000,200.0000,'core::ui',3,'2025-01-20 19:47:55','2025-01-20 23:11:22','2025-01-20 23:11:22'),
(14,1,'invoice',10,1,'Website','Webdesign',NULL,1.00,200.0000,38.0000,'undefined',0.0000,200.0000,'core::ui',3,'2025-01-20 23:16:02','2025-01-20 23:30:33','2025-01-20 23:30:33');
/*!40000 ALTER TABLE `tfb_document_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_document_totals`
--

DROP TABLE IF EXISTS `tfb_document_totals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_document_totals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `type` varchar(191) NOT NULL,
  `document_id` int(10) unsigned NOT NULL,
  `code` varchar(191) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `amount` double(15,4) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_document_totals_company_id_index` (`company_id`),
  KEY `tfb_document_totals_type_index` (`type`),
  KEY `tfb_document_totals_document_id_index` (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_document_totals`
--

LOCK TABLES `tfb_document_totals` WRITE;
/*!40000 ALTER TABLE `tfb_document_totals` DISABLE KEYS */;
INSERT INTO `tfb_document_totals` VALUES
(4,1,'invoice',1,'sub_total','invoices.sub_total',200.0000,1,'core::ui',1,'2024-12-18 18:41:54','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(5,1,'invoice',1,'tax','Umsatzsteuer',38.0000,2,'core::ui',1,'2024-12-18 18:41:54','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(6,1,'invoice',1,'total','invoices.total',238.0000,3,'core::ui',1,'2024-12-18 18:41:54','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(7,1,'invoice',2,'sub_total','invoices.sub_total',200.0000,1,'core::ui',1,'2024-12-18 23:36:43','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(8,1,'invoice',2,'tax','Umsatzsteuer',38.0000,2,'core::ui',1,'2024-12-18 23:36:43','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(9,1,'invoice',2,'total','invoices.total',238.0000,3,'core::ui',1,'2024-12-18 23:36:43','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(10,1,'invoice',3,'sub_total','invoices.sub_total',600.0000,1,'core::ui',1,'2024-12-19 11:01:17','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(11,1,'invoice',3,'tax','Umsatzsteuer',114.0000,2,'core::ui',1,'2024-12-19 11:01:17','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(12,1,'invoice',3,'total','invoices.total',714.0000,3,'core::ui',1,'2024-12-19 11:01:17','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(13,1,'invoice',4,'sub_total','invoices.sub_total',200.0000,1,'core::ui',1,'2024-12-19 11:32:36','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(14,1,'invoice',4,'tax','Umsatzsteuer',38.0000,2,'core::ui',1,'2024-12-19 11:32:36','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(15,1,'invoice',4,'total','invoices.total',238.0000,3,'core::ui',1,'2024-12-19 11:32:36','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(16,1,'invoice',5,'sub_total','invoices.sub_total',200.0000,1,'core::ui',1,'2024-12-19 12:09:39','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(17,1,'invoice',5,'tax','Umsatzsteuer',38.0000,2,'core::ui',1,'2024-12-19 12:09:39','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(18,1,'invoice',5,'total','invoices.total',238.0000,3,'core::ui',1,'2024-12-19 12:09:39','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(19,1,'invoice',6,'sub_total','invoices.sub_total',0.0000,1,'core::ui',1,'2024-12-19 17:27:00','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(20,1,'invoice',6,'total','invoices.total',0.0000,2,'core::ui',1,'2024-12-19 17:27:00','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(21,1,'invoice',7,'sub_total','invoices.sub_total',600.0000,1,'core::ui',1,'2024-12-20 16:30:12','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(22,1,'invoice',7,'tax','Umsatzsteuer',114.0000,2,'core::ui',1,'2024-12-20 16:30:12','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(23,1,'invoice',7,'total','invoices.total',714.0000,3,'core::ui',1,'2024-12-20 16:30:12','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(24,1,'invoice',8,'sub_total','invoices.sub_total',200.0000,1,'core::ui',3,'2025-01-20 19:04:25','2025-01-20 23:12:48','2025-01-20 23:12:48'),
(25,1,'invoice',8,'tax','Umsatzsteuer',38.0000,2,'core::ui',3,'2025-01-20 19:04:25','2025-01-20 23:12:48','2025-01-20 23:12:48'),
(26,1,'invoice',8,'total','invoices.total',238.0000,3,'core::ui',3,'2025-01-20 19:04:25','2025-01-20 23:12:48','2025-01-20 23:12:48'),
(27,1,'invoice',9,'sub_total','invoices.sub_total',400.0000,1,'core::ui',3,'2025-01-20 19:47:55','2025-01-20 23:11:22','2025-01-20 23:11:22'),
(28,1,'invoice',9,'tax','Umsatzsteuer',76.0000,2,'core::ui',3,'2025-01-20 19:47:55','2025-01-20 23:11:22','2025-01-20 23:11:22'),
(29,1,'invoice',9,'total','invoices.total',476.0000,3,'core::ui',3,'2025-01-20 19:47:55','2025-01-20 23:11:22','2025-01-20 23:11:22'),
(30,1,'invoice',10,'sub_total','invoices.sub_total',200.0000,1,'core::ui',3,'2025-01-20 23:16:02','2025-01-20 23:30:33','2025-01-20 23:30:33'),
(31,1,'invoice',10,'tax','Umsatzsteuer',38.0000,2,'core::ui',3,'2025-01-20 23:16:02','2025-01-20 23:30:33','2025-01-20 23:30:33'),
(32,1,'invoice',10,'total','invoices.total',238.0000,3,'core::ui',3,'2025-01-20 23:16:02','2025-01-20 23:30:33','2025-01-20 23:30:33');
/*!40000 ALTER TABLE `tfb_document_totals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_documents`
--

DROP TABLE IF EXISTS `tfb_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `type` varchar(191) NOT NULL,
  `document_number` varchar(191) NOT NULL,
  `order_number` varchar(191) DEFAULT NULL,
  `status` varchar(191) NOT NULL,
  `issued_at` datetime NOT NULL,
  `due_at` datetime NOT NULL,
  `amount` double(15,4) NOT NULL,
  `currency_code` varchar(191) NOT NULL,
  `currency_rate` double(15,8) NOT NULL,
  `category_id` int(10) unsigned NOT NULL DEFAULT 1,
  `contact_id` int(10) unsigned NOT NULL,
  `contact_name` varchar(191) NOT NULL,
  `contact_email` varchar(191) DEFAULT NULL,
  `contact_tax_number` varchar(191) DEFAULT NULL,
  `contact_phone` varchar(191) DEFAULT NULL,
  `contact_address` text DEFAULT NULL,
  `contact_city` varchar(191) DEFAULT NULL,
  `contact_zip_code` varchar(191) DEFAULT NULL,
  `contact_state` varchar(191) DEFAULT NULL,
  `contact_country` varchar(191) DEFAULT NULL,
  `title` varchar(191) DEFAULT NULL,
  `subheading` varchar(191) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `footer` text DEFAULT NULL,
  `parent_id` int(10) unsigned NOT NULL DEFAULT 0,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfb_documents_document_number_deleted_at_company_id_type_unique` (`document_number`,`deleted_at`,`company_id`,`type`),
  KEY `tfb_documents_company_id_index` (`company_id`),
  KEY `tfb_documents_type_index` (`type`),
  KEY `tfb_documents_contact_id_index` (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_documents`
--

LOCK TABLES `tfb_documents` WRITE;
/*!40000 ALTER TABLE `tfb_documents` DISABLE KEYS */;
INSERT INTO `tfb_documents` VALUES
(1,1,'invoice','INV-00001',NULL,'sent','2024-12-17 19:41:54','2024-12-17 19:41:54',238.0000,'EUR',1.00000000,2,1,'Flyermeyer','matthias@mk-pages.com','221/345/3344','018281925','Obere Eisenstraße 18','Lauf an der Pegnitz','91207','Bayern','DE','Rechnung',NULL,NULL,NULL,0,'core::ui',1,'2024-12-17 22:46:41','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(2,1,'invoice','INV-00002',NULL,'draft','2024-12-19 00:36:43','2024-12-26 00:36:43',238.0000,'EUR',1.00000000,2,1,'Flyermeyer','matthias@mk-pages.com','221/345/3344','018281925','Obere Eisenstraße 18','Lauf an der Pegnitz','91207','Bayern','DE','Rechnung',NULL,NULL,'Bankverbindungen\r\nRaiffeisenbank Bamberg-Forchheim\r\nIBAN DE91 7639 1000 0002 4069 34\r\nBIC/Swift GENODEF1FOH',0,'core::ui',1,'2024-12-18 23:36:43','2025-01-20 18:58:52','2025-01-20 18:58:52'),
(3,1,'invoice','INV-00003',NULL,'draft','2024-12-19 12:01:17','2024-12-26 12:01:17',714.0000,'EUR',1.00000000,2,1,'Flyermeyer','matthias@mk-pages.com','221/345/3344','018281925','Obere Eisenstraße 18','Lauf an der Pegnitz','91207','Bayern','DE','Rechnung',NULL,NULL,'Bankverbindungen\r\nRaiffeisenbank Bamberg-Forchheim\r\nIBAN DE91 7639 1000 0002 4069 34\r\nBIC/Swift GENODEF1FOH',0,'core::ui',1,'2024-12-19 11:01:17','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(4,1,'invoice','INV-00004',NULL,'draft','2024-12-19 12:32:36','2024-12-26 12:32:36',238.0000,'EUR',1.00000000,2,1,'Flyermeyer','matthias@mk-pages.com','221/345/3344','018281925','Obere Eisenstraße 18','Lauf an der Pegnitz','91207','Bayern','DE','Rechnung',NULL,NULL,'Bankverbindungen\r\nRaiffeisenbank Bamberg-Forchheim\r\nIBAN DE91 7639 1000 0002 4069 34\r\nBIC/Swift GENODEF1FOH',0,'core::ui',1,'2024-12-19 11:32:36','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(5,1,'invoice','INV-00005',NULL,'sent','2024-12-19 13:09:39','2024-12-26 13:09:39',238.0000,'EUR',1.00000000,2,1,'Flyermeyer','matthias@mk-pages.com','221/345/3344','018281925','Obere Eisenstraße 18','Lauf an der Pegnitz','91207','Bayern','DE','Rechnung',NULL,NULL,'Bankverbindungen\r\nRaiffeisenbank Bamberg-Forchheim\r\nIBAN DE91 7639 1000 0002 4069 34\r\nBIC/Swift GENODEF1FOH',0,'core::ui',1,'2024-12-19 12:09:39','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(6,1,'invoice','INV-00006',NULL,'draft','2024-12-19 18:27:00','2024-12-26 18:27:00',0.0000,'EUR',1.00000000,2,1,'Flyermeyer','matthias@mk-pages.com','221/345/3344','018281925','Obere Eisenstraße 18','Lauf an der Pegnitz','91207','Bayern','DE','Rechnung',NULL,'Enthalten sind 37 Euro lohngeld','Bankverbindungen\r\nRaiffeisenbank Bamberg-Forchheim\r\nIBAN DE91 7639 1000 0002 4069 34\r\nBIC/Swift GENODEF1FOH',0,'core::ui',1,'2024-12-19 17:27:00','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(7,1,'invoice','INV-00007',NULL,'draft','2024-12-20 17:30:12','2024-12-27 17:30:12',714.0000,'EUR',1.00000000,2,1,'Flyermeyer','matthias@mk-pages.com','221/345/3344','018281925','Obere Eisenstraße 18','Lauf an der Pegnitz','91207','Bayern','DE','Rechnung',NULL,NULL,'Bankverbindungen\r\nRaiffeisenbank Bamberg-Forchheim\r\nIBAN DE91 7639 1000 0002 4069 34\r\nBIC/Swift GENODEF1FOH',0,'core::ui',1,'2024-12-20 16:30:12','2025-01-20 18:58:53','2025-01-20 18:58:53'),
(8,1,'invoice','INV-00008',NULL,'draft','2025-01-20 19:04:25','2025-01-27 19:04:25',238.0000,'EUR',1.00000000,2,1,'Flyermeyer','matthias@mk-pages.com','221/345/3344','018281925','Obere Eisenstraße 18','Lauf an der Pegnitz','91207','Bayern','DE','Rechnung',NULL,NULL,'Bankverbindungen\r\nStadt- und Kreissparkasse Erlangen\r\nIBAN DE66 7635 0000 0026 0055 77\r\nBIC/Swift BYLADEM1ERH',0,'core::ui',3,'2025-01-20 19:04:25','2025-01-20 23:12:48','2025-01-20 23:12:48'),
(9,1,'invoice','INV-00009',NULL,'viewed','2025-01-20 19:47:55','2025-01-27 19:47:55',476.0000,'EUR',1.00000000,2,1,'Flyermeyer','matthias@mk-pages.com','221/345/3344','018281925','Obere Eisenstraße 18','Lauf an der Pegnitz','91207','Bayern','DE','Rechnung',NULL,NULL,'Bankverbindungen\r\nStadt- und Kreissparkasse Erlangen\r\nIBAN DE66 7635 0000 0026 0055 77\r\nBIC/Swift BYLADEM1ERH',0,'core::ui',3,'2025-01-20 19:47:55','2025-01-20 23:11:22','2025-01-20 23:11:22'),
(10,1,'invoice','2025-00001',NULL,'draft','2025-01-20 23:16:02','2025-01-27 23:16:02',238.0000,'EUR',1.00000000,2,1,'Flyermeyer','matthias@mk-pages.com','221/345/3344','018281925','Obere Eisenstraße 18','Lauf an der Pegnitz','91207','Bayern','DE','Rechnung',NULL,NULL,'Bankverbindungen\r\nStadt- und Kreissparkasse Erlangen\r\nIBAN DE66 7635 0000 0026 0055 77\r\nBIC/Swift BYLADEM1ERH',0,'core::ui',3,'2025-01-20 23:16:02','2025-01-20 23:30:33','2025-01-20 23:30:33');
/*!40000 ALTER TABLE `tfb_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_email_templates`
--

DROP TABLE IF EXISTS `tfb_email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_email_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `alias` varchar(191) NOT NULL,
  `class` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `subject` varchar(191) NOT NULL,
  `body` text NOT NULL,
  `params` text DEFAULT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfb_email_templates_company_id_alias_deleted_at_unique` (`company_id`,`alias`,`deleted_at`),
  KEY `tfb_email_templates_company_id_index` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_email_templates`
--

LOCK TABLES `tfb_email_templates` WRITE;
/*!40000 ALTER TABLE `tfb_email_templates` DISABLE KEYS */;
INSERT INTO `tfb_email_templates` VALUES
(1,1,'invoice_new_customer','App\\Notifications\\Sale\\Invoice','settings.email.templates.invoice_new_customer','Rechnung {invoice_number} erstellt','Hallo {customer_name},<br /><br />Wir haben Ihnen folgende Rechnung vorbereitet: <strong>{invoice_number}</strong>.<br /><br />Sie können die Rechnungsdaten einsehen und mit der Zahlung fortfahren: <a href=\"{invoice_guest_link}\">{invoice_number}</a>.<br /><br />Zögern Sie nicht, uns für jede Frage zu kontaktieren.<br /><br />Herzliche Grüße,<br />{company_name}',NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(2,1,'invoice_remind_customer','App\\Notifications\\Sale\\Invoice','settings.email.templates.invoice_remind_customer','Rechnung {invoice_number} ist überfällig','Hallo {customer_name},<br /><br />Die Rechnung <strong>{invoice_number}</strong> ist bis heute noch nicht bezahlt worden.<br /><br />Der Rechnungsbetrag beträgt {invoice_total} und war fällig am <strong>{invoice_due_date}</strong>.<br /><br />Sie können die Rechnungsdaten einsehen und mit der Zahlung fortfahren: <a href=\"{invoice_guest_link}\">{invoice_number}</a>.<br /><br />Beste Grüße,<br />{company_name}',NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(3,1,'invoice_remind_admin','App\\Notifications\\Sale\\Invoice','settings.email.templates.invoice_remind_admin','Rechnung {invoice_number} ist überfällig','Hallo,<br /><br />{customer_name} hat eine Mitteilung für die überfällige Rechnung <strong>{invoice_number}</strong> erhalten.<br /><br />Der Rechnungsbetrag beträgt {invoice_total} und war fällig am <strong>{invoice_due_date}</strong>.<br /><br />Sie können die Rechnungsdaten unter folgendem Link einsehen: <a href=\"{invoice_admin_link}\">{invoice_number}</a>.<br /><br />Beste Grüße,<br />{company_name}',NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(4,1,'invoice_recur_customer','App\\Notifications\\Sale\\Invoice','settings.email.templates.invoice_recur_customer','Rechnung {invoice_number} - wiederkehrende Rechnung erstellt','Hallo {customer_name},<br /><br />Basierend auf Ihrem wiederkehrenden Kreis, wir haben für Sie folgende Rechnung vorbereitet: <strong>{invoice_number}</strong>.<br /><br />Sie können die Rechnungsdaten einsehen und mit der Zahlung fortfahren: <a href=\"{invoice_guest_link}\">{invoice_number}</a>.<br /><br />Zögern Sie nicht, uns für jede Frage zu kontaktieren.<br /><br />Herzliche Grüße,<br />{company_name}',NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(5,1,'invoice_recur_admin','App\\Notifications\\Sale\\Invoice','settings.email.templates.invoice_recur_admin','Rechnung {invoice_number} - wiederkehrende Rechnung erstellt','Hallo,<br /><br /> Basierend auf {customer_name} wiederkehrenden Kreis, <strong>{invoice_number}</strong> Rechnung wurde automatisch erstellt.<br /><br />Sie können die Rechnungsdaten unter folgendem Link sehen: <a href=\"{invoice_admin_link}\">{invoice_number}</a>.<br /><br />Beste Grüße,<br />{company_name}',NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(6,1,'invoice_view_admin','App\\Notifications\\Sale\\Invoice','settings.email.templates.invoice_view_admin','Rechnung {invoice_number} angesehen','Hallo,<br /><br />{customer_name} hat die Rechnung <strong>{invoice_number}</strong> angesehen.<br /><br />Sie können die Rechnungsdetails unter folgendem Link einsehen: <a href =\"{invoice_admin_link}\">{invoice_number}</a>.<br /><br />Mit freundlichen Grüßen<br />{company_name}',NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(7,1,'invoice_payment_customer','App\\Notifications\\Portal\\PaymentReceived','settings.email.templates.invoice_payment_customer','Zahlung für Rechnung {invoice_number} erhalten','Hallo {customer_name},<br /><br />Vielen Dank für die Zahlung. Sie finden die Zahlungsinformationen unten:<br /><br />-------------------------------------------------<br /><br />Betrag: <strong>{transaction_total}<br /></strong>Datum: <strong>{transaction_paid_date}</strong><br />Rechnungsnummer: <strong>{invoice_number}<br /><br /></strong>-------------------------------------------------<br /><br />Sie können die Rechnungsdetails immer unter folgendem Link sehen: <a href=\"{invoice_guest_link}\">{invoice_number}</a>.<br /><br />Zögern Sie nicht, uns für jede Frage zu kontaktieren.<br /><br />Beste Grüße,<br />{company_name}',NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(8,1,'invoice_payment_admin','App\\Notifications\\Portal\\PaymentReceived','settings.email.templates.invoice_payment_admin','Zahlung für Rechnung {invoice_number} erhalten','Hallo,<br /><br />{customer_name} hat die Rechnung <strong>{invoice_number}</strong> bezhalt.<br /><br />Sie können die Rechnungsdaten unter folgendem Link sehen: <a href=\"{invoice_admin_link}\">{invoice_number}</a>.<br /><br />Beste Grüße,<br />{company_name}',NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(9,1,'bill_remind_admin','App\\Notifications\\Purchase\\Bill','settings.email.templates.bill_remind_admin','Die Rechnung {bill_number} ist überfällig (Ausgaben)','Hallo,<br /><br />Dies Rechnung <strong>{bill_number}</strong> von {vendor_name} ist überfällig.<br /><br />Die Rechnung beträgt insgesamt {bill_total} und ist fällig <strong>{bill_due_date}</strong>.<br /><br />Die Details der Rechnung sehen Sie unter folgendem Link: <a href=\"{bill_admin_link}\">{bill_number}</a>.<br /><br />Beste Grüße,<br />{company_name}',NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(10,1,'bill_recur_admin','App\\Notifications\\Purchase\\Bill','settings.email.templates.bill_recur_admin','Rechnung {bill_number} - wiederkehrende Rechnung (Ausgaben)','Hallo,<br /><br /> Basierend auf {vendor_name} wiederkehrenden Kreis, <strong>{bill_number}</strong> Rechnung wurde automatisch erstellt.<br /><br />Sie können die Details der Rechnung unter folgendem Link sehen: <a href=\"{bill_admin_link}\">{bill_number}</a>.<br /><br />Beste Grüße,<br />{company_name}',NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(11,1,'payment_received_customer','App\\Notifications\\Banking\\Transaction','settings.email.templates.payment_received_customer','Deine Quittung von {company_name}','Hallo {contact_name},<br /><br />Vielen Dank für die Zahlung. <br /><br />Sie können die Zahlungsdetails unter folgendem Link einsehen: <a href=\"{payment_guest_link}\">{payment_date}</a>.<br /><br />Sie können uns gerne kontaktieren bei Fragen.<br /><br />Mit freundlichen Grüßen<br />{company_name}',NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(12,1,'payment_made_vendor','App\\Notifications\\Banking\\Transaction','settings.email.templates.payment_made_vendor','Zahlung erfolgt durch {company_name}','Hallo {contact_name},<br /><br />wir haben die folgende Zahlung geleistet. <br /><br />Sie können die Zahlungsdetails unter folgendem Link einsehen: <a href=\"{payment_guest_link}\">{payment_date}</a>.<br /><br />Sie können uns gerne kontaktieren bei Fragen.<br /><br />Mit freundlichen Grüßen<br />{company_name}',NULL,'core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL);
/*!40000 ALTER TABLE `tfb_email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_failed_jobs`
--

DROP TABLE IF EXISTS `tfb_failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) DEFAULT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfb_failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_failed_jobs`
--

LOCK TABLES `tfb_failed_jobs` WRITE;
/*!40000 ALTER TABLE `tfb_failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tfb_failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_firewall_ips`
--

DROP TABLE IF EXISTS `tfb_firewall_ips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_firewall_ips` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(191) NOT NULL,
  `log_id` int(11) DEFAULT NULL,
  `blocked` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfb_firewall_ips_ip_deleted_at_unique` (`ip`,`deleted_at`),
  KEY `tfb_firewall_ips_ip_index` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_firewall_ips`
--

LOCK TABLES `tfb_firewall_ips` WRITE;
/*!40000 ALTER TABLE `tfb_firewall_ips` DISABLE KEYS */;
/*!40000 ALTER TABLE `tfb_firewall_ips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_firewall_logs`
--

DROP TABLE IF EXISTS `tfb_firewall_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_firewall_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(191) NOT NULL,
  `level` varchar(191) NOT NULL DEFAULT 'medium',
  `middleware` varchar(191) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `url` varchar(191) DEFAULT NULL,
  `referrer` varchar(191) DEFAULT NULL,
  `request` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_firewall_logs_ip_index` (`ip`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_firewall_logs`
--

LOCK TABLES `tfb_firewall_logs` WRITE;
/*!40000 ALTER TABLE `tfb_firewall_logs` DISABLE KEYS */;
INSERT INTO `tfb_firewall_logs` VALUES
(1,'91.39.151.140','medium','login',0,'https://accounting.mk-pages.com/auth/login','https://accounting.mk-pages.com/auth/login','_token=3oigvaMEe1mpPohz4IW2QmiRKR5BfqzfbWpyoGX2&_method=POST&email=matthias@mk-pages.com&password=******&remember=true','2024-10-02 21:03:16','2024-10-02 21:03:16',NULL),
(2,'91.39.151.140','medium','login',0,'https://accounting.mk-pages.com/auth/login','https://accounting.mk-pages.com/auth/login','_token=3oigvaMEe1mpPohz4IW2QmiRKR5BfqzfbWpyoGX2&_method=POST&email=matthias@mk-pages.com&password=******&remember=true','2024-10-02 21:03:26','2024-10-02 21:03:26',NULL),
(3,'91.39.151.140','medium','login',0,'https://accounting.mk-pages.com/auth/login','https://accounting.mk-pages.com/auth/login','_token=3oigvaMEe1mpPohz4IW2QmiRKR5BfqzfbWpyoGX2&_method=POST&email=matthias@mk-pages.com&password=******&remember=true','2024-10-02 21:03:49','2024-10-02 21:03:49',NULL),
(4,'135.148.100.196','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-10-14 14:28:08','2024-10-14 14:28:08',NULL),
(5,'135.148.100.196','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-11-13 13:59:40','2024-11-13 13:59:40',NULL),
(6,'154.216.20.167','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-11-21 00:50:23','2024-11-21 00:50:23',NULL),
(7,'154.216.20.167','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-11-21 00:50:24','2024-11-21 00:50:24',NULL),
(8,'154.216.20.167','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-11-21 00:50:25','2024-11-21 00:50:25',NULL),
(9,'3.27.47.59','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-11-25 07:33:46','2024-11-25 07:33:46',NULL),
(10,'3.27.47.59','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-11-25 07:33:47','2024-11-25 07:33:47',NULL),
(11,'3.27.47.59','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-11-25 07:33:49','2024-11-25 07:33:49',NULL),
(12,'154.216.20.167','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-11-27 19:11:32','2024-11-27 19:11:32',NULL),
(13,'154.216.20.167','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-11-27 19:11:33','2024-11-27 19:11:33',NULL),
(14,'154.216.20.167','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-11-27 19:11:34','2024-11-27 19:11:34',NULL),
(15,'3.95.67.52','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-12-11 18:46:55','2024-12-11 18:46:55',NULL),
(16,'3.95.67.52','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-12-11 18:46:56','2024-12-11 18:46:56',NULL),
(17,'3.95.67.52','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-12-11 18:46:57','2024-12-11 18:46:57',NULL),
(18,'54.206.37.173','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-12-14 11:13:51','2024-12-14 11:13:51',NULL),
(19,'87.120.114.34','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2024-12-16 23:22:50','2024-12-16 23:22:50',NULL),
(20,'2003:c2:c703:9707:562b:7f2a:5aba:32d9','medium','login',0,'https://accounting.mk-pages.com/auth/login','https://accounting.mk-pages.com/auth/login','_token=wjRW210xVZqjw44DtnLVLhbSpJ3iIwA45Ezhgr4e&_method=POST&email=matthias@mk-pages.com&password=******','2024-12-17 21:43:17','2024-12-17 21:43:17',NULL),
(21,'2003:c2:c726:e400:71f1:64f4:8849:a875','medium','login',0,'https://accounting.mk-pages.com/auth/login','https://accounting.mk-pages.com/auth/login','_token=Pc7cI2UYdxuvgXXWC7IpCUEHGX5nWNBvSm0pk26z&_method=POST&email=matthias@mk-pages.com&password=******&remember=true','2024-12-19 09:33:04','2024-12-19 09:33:04',NULL),
(22,'87.120.126.223','medium','agent',0,'https://accounting.mk-pages.com','NULL','','2025-01-02 17:31:42','2025-01-02 17:31:42',NULL),
(23,'2003:c2:c726:e400:f1ef:eafe:2ede:d4fc','medium','login',0,'https://accounting.mk-pages.com/auth/login','https://accounting.mk-pages.com/auth/login','_token=GAd9mzHAqNfQqoh8fkW3GcEo8cgvqopsLzNZW1Ke&_method=POST&email=matthias@mk-pages.com&password=******&remember=true','2025-01-06 15:53:17','2025-01-06 15:53:17',NULL),
(24,'51.81.46.212','medium','agent',0,'https://zugferd.mk-pages.com','NULL','','2025-01-09 17:07:44','2025-01-09 17:07:44',NULL),
(25,'88.217.180.132','medium','login',0,'https://zugferd.mk-pages.com/auth/login','https://zugferd.mk-pages.com/auth/login','_token=CUoe4qsz82Xq5rub4uWJXf2NVhx4OQ4H6umSDRh8&_method=POST&email=jari.madubuko@ifastnet1.com&password=******&remember=true','2025-01-09 19:10:11','2025-01-09 19:10:11',NULL),
(26,'88.217.180.132','medium','login',0,'https://zugferd.mk-pages.com/auth/login','https://zugferd.mk-pages.com/auth/login','_token=CUoe4qsz82Xq5rub4uWJXf2NVhx4OQ4H6umSDRh8&_method=POST&email=jari.madubuko@ifastnet1.com&password=******&remember=false','2025-01-09 19:10:33','2025-01-09 19:10:33',NULL),
(27,'88.217.180.132','medium','login',0,'https://zugferd.mk-pages.com/auth/login','https://zugferd.mk-pages.com/auth/login','_token=CUoe4qsz82Xq5rub4uWJXf2NVhx4OQ4H6umSDRh8&_method=POST&email=gordonb95@yahoo.com&password=******&remember=true','2025-01-09 19:10:51','2025-01-09 19:10:51',NULL),
(28,'88.217.180.132','medium','login',0,'https://zugferd.mk-pages.com/auth/login','https://zugferd.mk-pages.com/auth/login','_token=CUoe4qsz82Xq5rub4uWJXf2NVhx4OQ4H6umSDRh8&_method=POST&email=jari.madubuko@ifastnet1.com&password=******&remember=false','2025-01-09 19:11:09','2025-01-09 19:11:09',NULL),
(29,'88.217.180.132','medium','login',0,'https://zugferd.mk-pages.com/auth/login','https://zugferd.mk-pages.com/auth/login','_token=CUoe4qsz82Xq5rub4uWJXf2NVhx4OQ4H6umSDRh8&_method=POST&email=isobel72@hotmail.com&password=******&remember=true','2025-01-09 19:11:26','2025-01-09 19:11:26',NULL),
(30,'88.217.180.132','medium','login',0,'https://zugferd.mk-pages.com/auth/login','https://zugferd.mk-pages.com/auth/login','_token=CUoe4qsz82Xq5rub4uWJXf2NVhx4OQ4H6umSDRh8&_method=POST&email=isobel72@hotmail.com&password=******&remember=true','2025-01-09 19:11:41','2025-01-09 19:11:41',NULL),
(31,'88.217.180.132','medium','login',0,'https://zugferd.mk-pages.com/auth/login','https://zugferd.mk-pages.com/auth/login','_token=CUoe4qsz82Xq5rub4uWJXf2NVhx4OQ4H6umSDRh8&_method=POST&email=isobel72@hotmail.com&password=******','2025-01-09 19:12:00','2025-01-09 19:12:00',NULL),
(32,'51.161.134.48','medium','agent',0,'https://zugferd.mk-pages.com','NULL','','2025-01-09 19:28:16','2025-01-09 19:28:16',NULL),
(33,'198.235.24.133','medium','agent',0,'https://zugferd.mk-pages.com','http://194.164.58.217:80/','','2025-01-17 21:53:07','2025-01-17 21:53:07',NULL),
(34,'198.235.24.49','medium','agent',0,'https://zugferd.mk-pages.com','NULL','','2025-01-19 22:56:30','2025-01-19 22:56:30',NULL),
(35,'2003:fa:701:6600:c051:316:af03:ea51','medium','login',0,'https://zugferd.mk-pages.com/auth/login','https://zugferd.mk-pages.com/auth/login','_token=CPwhVbTAFAUVK9Or7z4AjG7YhrU11Mz8N0Z7Oedp&_method=POST&email=info@mk-pages.com&password=******&remember=true','2025-01-20 17:55:57','2025-01-20 17:55:57',NULL);
/*!40000 ALTER TABLE `tfb_firewall_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_item_taxes`
--

DROP TABLE IF EXISTS `tfb_item_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_item_taxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `tax_id` int(11) DEFAULT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_item_taxes_company_id_item_id_index` (`company_id`,`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_item_taxes`
--

LOCK TABLES `tfb_item_taxes` WRITE;
/*!40000 ALTER TABLE `tfb_item_taxes` DISABLE KEYS */;
INSERT INTO `tfb_item_taxes` VALUES
(1,1,1,1,'core::ui',1,'2024-12-17 22:46:41','2024-12-17 22:46:41',NULL);
/*!40000 ALTER TABLE `tfb_item_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_items`
--

DROP TABLE IF EXISTS `tfb_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_items` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(191) NOT NULL DEFAULT 'product',
  `name` varchar(191) NOT NULL,
  `sku` varchar(191) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `sale_price` double DEFAULT NULL,
  `purchase_price` double DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_items_company_id_index` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_items`
--

LOCK TABLES `tfb_items` WRITE;
/*!40000 ALTER TABLE `tfb_items` DISABLE KEYS */;
INSERT INTO `tfb_items` VALUES
(1,1,'product','Website',NULL,'Webdesign',200,200,NULL,1,'core::ui',1,'2024-12-17 22:46:41','2024-12-17 22:46:41',NULL);
/*!40000 ALTER TABLE `tfb_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_jobs`
--

DROP TABLE IF EXISTS `tfb_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_jobs_queue_reserved_at_index` (`queue`,`reserved_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_jobs`
--

LOCK TABLES `tfb_jobs` WRITE;
/*!40000 ALTER TABLE `tfb_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tfb_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_media`
--

DROP TABLE IF EXISTS `tfb_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL DEFAULT 0,
  `disk` varchar(32) NOT NULL,
  `directory` varchar(191) NOT NULL,
  `filename` varchar(191) NOT NULL,
  `extension` varchar(32) NOT NULL,
  `mime_type` varchar(128) NOT NULL,
  `aggregate_type` varchar(32) NOT NULL,
  `size` int(10) unsigned NOT NULL,
  `variant_name` varchar(255) DEFAULT NULL,
  `original_media_id` int(10) unsigned DEFAULT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfb_media_disk_directory_filename_extension_unique` (`disk`,`directory`,`filename`,`extension`),
  UNIQUE KEY `tfb_media_disk_directory_filename_extension_deleted_at_unique` (`disk`,`directory`,`filename`,`extension`,`deleted_at`),
  KEY `tfb_media_aggregate_type_index` (`aggregate_type`),
  KEY `tfb_media_disk_directory_index` (`disk`,`directory`),
  KEY `tfb_media_company_id_index` (`company_id`),
  KEY `original_media_id` (`original_media_id`),
  CONSTRAINT `original_media_id` FOREIGN KEY (`original_media_id`) REFERENCES `tfb_media` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_media`
--

LOCK TABLES `tfb_media` WRITE;
/*!40000 ALTER TABLE `tfb_media` DISABLE KEYS */;
INSERT INTO `tfb_media` VALUES
(1,1,'uploads','2024/12/19/1/settings','mk-1-e1645642471155','png','image/png','image',101584,NULL,NULL,'::ui',1,'2024-12-18 23:22:11','2024-12-18 23:22:11',NULL),
(2,1,'uploads','2025/01/09/1/settings','Datum-Benutzerdefiniert','png','image/png','image',50417,NULL,NULL,'::ui',1,'2025-01-09 15:20:12','2025-01-09 15:20:12',NULL),
(3,1,'uploads','2025/01/09/1/settings','Design-ohne-Titel-3','png','image/png','image',25270,NULL,NULL,'::ui',1,'2025-01-09 15:26:31','2025-01-09 15:26:31',NULL);
/*!40000 ALTER TABLE `tfb_media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_mediables`
--

DROP TABLE IF EXISTS `tfb_mediables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_mediables` (
  `media_id` int(10) unsigned NOT NULL,
  `company_id` int(10) unsigned NOT NULL DEFAULT 0,
  `mediable_type` varchar(191) NOT NULL,
  `mediable_id` int(10) unsigned NOT NULL,
  `tag` varchar(191) NOT NULL,
  `order` int(10) unsigned NOT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`media_id`,`mediable_type`,`mediable_id`,`tag`),
  KEY `tfb_mediables_mediable_id_mediable_type_index` (`mediable_id`,`mediable_type`),
  KEY `tfb_mediables_tag_index` (`tag`),
  KEY `tfb_mediables_order_index` (`order`),
  KEY `tfb_mediables_company_id_index` (`company_id`),
  CONSTRAINT `tfb_mediables_media_id_foreign` FOREIGN KEY (`media_id`) REFERENCES `tfb_media` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_mediables`
--

LOCK TABLES `tfb_mediables` WRITE;
/*!40000 ALTER TABLE `tfb_mediables` DISABLE KEYS */;
INSERT INTO `tfb_mediables` VALUES
(1,1,'App\\Models\\Common\\Company',1,'company.logo',1,'::ui',1),
(2,1,'App\\Models\\Common\\Company',1,'company.logo',2,'::ui',1),
(3,1,'App\\Models\\Common\\Company',1,'company.logo',3,'::ui',1);
/*!40000 ALTER TABLE `tfb_mediables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_migrations`
--

DROP TABLE IF EXISTS `tfb_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_migrations`
--

LOCK TABLES `tfb_migrations` WRITE;
/*!40000 ALTER TABLE `tfb_migrations` DISABLE KEYS */;
INSERT INTO `tfb_migrations` VALUES
(1,'2016_06_27_000000_create_mediable_tables',1),
(2,'2017_09_14_000000_core_v1',1),
(3,'2019_11_16_000000_core_v2',1),
(4,'2020_10_12_000000_add_variants_to_media',1),
(5,'2022_05_10_000000_core_v300',1),
(6,'2022_06_28_000000_core_v304',1),
(7,'2022_07_21_000000_core_v305',1),
(8,'2022_08_29_000000_core_v3015',1),
(9,'2022_08_29_000000_core_v307',1),
(10,'2023_06_22_000000_core_v3016',1),
(11,'2023_08_14_000000_core_v3017',1),
(12,'2023_10_03_000000_core_v310',1);
/*!40000 ALTER TABLE `tfb_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_module_histories`
--

DROP TABLE IF EXISTS `tfb_module_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_module_histories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `version` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_module_histories_company_id_module_id_index` (`company_id`,`module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_module_histories`
--

LOCK TABLES `tfb_module_histories` WRITE;
/*!40000 ALTER TABLE `tfb_module_histories` DISABLE KEYS */;
INSERT INTO `tfb_module_histories` VALUES
(1,1,1,'3.0.4','offline-payments installiert','::ui',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(2,1,2,'3.0.1','paypal-standard installiert','::ui',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL);
/*!40000 ALTER TABLE `tfb_module_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_modules`
--

DROP TABLE IF EXISTS `tfb_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `alias` varchar(191) NOT NULL,
  `enabled` int(11) NOT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfb_modules_company_id_alias_deleted_at_unique` (`company_id`,`alias`,`deleted_at`),
  KEY `tfb_modules_company_id_index` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_modules`
--

LOCK TABLES `tfb_modules` WRITE;
/*!40000 ALTER TABLE `tfb_modules` DISABLE KEYS */;
INSERT INTO `tfb_modules` VALUES
(1,1,'offline-payments',1,'::ui',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(2,1,'paypal-standard',1,'::ui',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL);
/*!40000 ALTER TABLE `tfb_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_notifications`
--

DROP TABLE IF EXISTS `tfb_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(191) NOT NULL,
  `notifiable_type` varchar(191) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_notifications`
--

LOCK TABLES `tfb_notifications` WRITE;
/*!40000 ALTER TABLE `tfb_notifications` DISABLE KEYS */;
INSERT INTO `tfb_notifications` VALUES
('11343f06-5015-4ba1-88b6-4468de84fc72','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:45:40','2025-01-09 15:45:40'),
('1bcfb9bd-e24c-4994-9265-0e5f2f5affc3','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00001<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/portal\\/invoices\\/1\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":1,\"invoice_number\":\"INV-00001\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"17 Dez 2024\",\"invoice_due_date\":\"17 Dez 2024\",\"status\":\"sent\"}',NULL,'2024-12-18 19:19:58','2024-12-18 19:19:58'),
('1de49008-d97d-400d-bbf4-ddb61ea6eeca','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:33:43','2025-01-09 15:33:43'),
('233dc7c2-018e-41ef-ab43-77d6245781ce','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00001<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/portal\\/invoices\\/1\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":1,\"invoice_number\":\"INV-00001\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"17 Dez 2024\",\"invoice_due_date\":\"17 Dez 2024\",\"status\":\"sent\"}',NULL,'2024-12-18 21:29:57','2024-12-18 21:29:57'),
('268bf573-6d15-4ce1-a3cb-d6b70c00e009','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-06 16:59:00','2025-01-06 16:59:00'),
('273fcf0f-cc63-46b5-abe7-57e7635917f7','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:24:51','2025-01-09 15:24:51'),
('2882c0f4-1dc1-408d-a8ae-0bb14f6bb42e','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:50:28','2025-01-09 15:50:28'),
('2aeb1c2f-cadb-4dd8-952c-0f49c3761f44','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 17:01:39','2024-12-21 17:01:39'),
('2efae45c-eda6-409d-9ef9-b9be2883230e','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00009<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/portal\\/invoices\\/9\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":9,\"invoice_number\":\"INV-00009\",\"customer_name\":\"Flyermeyer\",\"amount\":476,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"sent\"}',NULL,'2025-01-20 21:29:26','2025-01-20 21:29:26'),
('3342744b-535b-4a29-8475-8a8e8dbdf925','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:58:09','2025-01-09 15:58:09'),
('36831820-631e-4503-9e3f-6d61d375df2a','App\\Notifications\\Sale\\Invoice','users',3,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00008<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/8\\\">click here<\\/a> to see the details.\",\"invoice_id\":8,\"invoice_number\":\"INV-00008\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"draft\"}',NULL,'2025-01-20 19:14:16','2025-01-20 19:14:16'),
('36bbba19-2a4e-41c6-a0ab-3451ed42b21f','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:58:22','2024-12-21 16:58:22'),
('39908fbb-58cd-4373-82ed-d2102afeafa4','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00003<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/3\\\">click here<\\/a> to see the details.\",\"invoice_id\":3,\"invoice_number\":\"INV-00003\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:13:25','2024-12-21 16:13:25'),
('3b6e01f2-0a43-48dc-bc85-ae9e62ef4eb5','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00003<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/3\\\">click here<\\/a> to see the details.\",\"invoice_id\":3,\"invoice_number\":\"INV-00003\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:13:34','2024-12-21 16:13:34'),
('3f4cb8c5-3c16-4856-967b-493a00908b8e','App\\Notifications\\Sale\\Invoice','users',3,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00009<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/9\\\">click here<\\/a> to see the details.\",\"invoice_id\":9,\"invoice_number\":\"INV-00009\",\"customer_name\":\"Flyermeyer\",\"amount\":476,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"draft\"}',NULL,'2025-01-20 19:50:12','2025-01-20 19:50:12'),
('499e5baa-cd8d-4955-abed-7fce11d000a8','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00001<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/portal\\/invoices\\/1\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":1,\"invoice_number\":\"INV-00001\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"17 Dez 2024\",\"invoice_due_date\":\"17 Dez 2024\",\"status\":\"sent\"}',NULL,'2024-12-18 22:33:58','2024-12-18 22:33:58'),
('53def10c-0c2b-4b1f-9234-fcb6e6c32c2e','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-20 18:45:10','2024-12-20 18:45:10'),
('55795449-95a6-452f-8ac8-9fd59b087cbb','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 16:00:49','2025-01-09 16:00:49'),
('637655a6-c36d-4e2c-8412-6a4cc7e05fe3','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00005<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/portal\\/invoices\\/5\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":5,\"invoice_number\":\"INV-00005\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-19 12:18:17','2024-12-19 12:18:17'),
('67f66e57-c892-449f-b70c-92dfd10245b1','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-20 17:04:29','2024-12-20 17:04:29'),
('69995883-9e9f-41d7-a1e3-b5e0c2848f11','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00001<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/portal\\/invoices\\/1\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":1,\"invoice_number\":\"INV-00001\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"17 Dez 2024\",\"invoice_due_date\":\"17 Dez 2024\",\"status\":\"sent\"}',NULL,'2024-12-18 21:54:22','2024-12-18 21:54:22'),
('6bd2771e-1f2a-4629-9b96-8c86cd916ad0','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00009<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/9\\\">click here<\\/a> to see the details.\",\"invoice_id\":9,\"invoice_number\":\"INV-00009\",\"customer_name\":\"Flyermeyer\",\"amount\":476,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"draft\"}',NULL,'2025-01-20 21:07:53','2025-01-20 21:07:53'),
('71b6df93-26a1-4c73-bb61-ea171dc8067f','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00003<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/3\\\">click here<\\/a> to see the details.\",\"invoice_id\":3,\"invoice_number\":\"INV-00003\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:27:23','2024-12-21 16:27:23'),
('73678a51-dca5-4e65-943b-38aaf14056ed','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00003<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/3\\\">click here<\\/a> to see the details.\",\"invoice_id\":3,\"invoice_number\":\"INV-00003\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:12:36','2024-12-21 16:12:36'),
('76627e1b-401f-434e-879a-77ca2ecf16b8','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:54:43','2024-12-21 16:54:43'),
('7b5d0c38-de34-4684-a538-7fe7e96e2892','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00009<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/portal\\/invoices\\/9\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":9,\"invoice_number\":\"INV-00009\",\"customer_name\":\"Flyermeyer\",\"amount\":476,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"sent\"}',NULL,'2025-01-20 21:30:07','2025-01-20 21:30:07'),
('7d19bec3-23ef-4e75-9697-588c3877de4d','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00001<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/portal\\/invoices\\/1\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":1,\"invoice_number\":\"INV-00001\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"17 Dez 2024\",\"invoice_due_date\":\"17 Dez 2024\",\"status\":\"sent\"}',NULL,'2024-12-18 19:53:14','2024-12-18 19:53:14'),
('7f78207c-8fee-4fc3-9da0-0bb36ee92136','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00008<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/8\\\">click here<\\/a> to see the details.\",\"invoice_id\":8,\"invoice_number\":\"INV-00008\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"draft\"}',NULL,'2025-01-20 19:05:30','2025-01-20 19:05:30'),
('80248db8-4c57-4328-b90c-8b93a5cc29a9','App\\Notifications\\Sale\\Invoice','users',3,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00009<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/9\\\">click here<\\/a> to see the details.\",\"invoice_id\":9,\"invoice_number\":\"INV-00009\",\"customer_name\":\"Flyermeyer\",\"amount\":476,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"draft\"}',NULL,'2025-01-20 21:07:53','2025-01-20 21:07:53'),
('81ea6669-c5c9-4eee-a011-8e5f933bc4d4','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00003<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/3\\\">click here<\\/a> to see the details.\",\"invoice_id\":3,\"invoice_number\":\"INV-00003\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:08:11','2024-12-21 16:08:11'),
('85d5c233-779e-4b5f-8cff-c545c0785fcc','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:43:25','2025-01-09 15:43:25'),
('910afe9c-3cba-4f97-890b-35d906b162c0','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00003<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/3\\\">click here<\\/a> to see the details.\",\"invoice_id\":3,\"invoice_number\":\"INV-00003\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:18:14','2024-12-21 16:18:14'),
('913aaeb9-59ed-48f2-857e-9f7a11826299','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:30:15','2025-01-09 15:30:15'),
('92d82d1b-6b67-49f0-b15c-ec1ca64450c4','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00003<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/3\\\">click here<\\/a> to see the details.\",\"invoice_id\":3,\"invoice_number\":\"INV-00003\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:09:27','2024-12-21 16:09:27'),
('95f6ad95-d454-4886-b674-b11707c7d41d','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00005<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/5\\\">click here<\\/a> to see the details.\",\"invoice_id\":5,\"invoice_number\":\"INV-00005\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-19 12:13:46','2024-12-19 12:13:46'),
('95f9105c-1265-40cd-8b36-dc97a450dde7','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00002<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/2\\\">click here<\\/a> to see the details.\",\"invoice_id\":2,\"invoice_number\":\"INV-00002\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-06 18:36:39','2025-01-06 18:36:39'),
('96af9cd3-4c2a-4fba-95c6-c9815270a8df','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00002<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/2\\\">click here<\\/a> to see the details.\",\"invoice_id\":2,\"invoice_number\":\"INV-00002\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-06 18:37:08','2025-01-06 18:37:08'),
('9824a39d-be1f-439c-9494-958371eff8cd','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:10:33','2025-01-09 15:10:33'),
('988a59a5-c775-4eb8-8f67-49d271fc2bf3','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00001<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/portal\\/invoices\\/1\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":1,\"invoice_number\":\"INV-00001\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"17 Dez 2024\",\"invoice_due_date\":\"17 Dez 2024\",\"status\":\"sent\"}',NULL,'2024-12-18 19:21:30','2024-12-18 19:21:30'),
('9e8edfc4-6ce2-49ae-8d89-184b37e46224','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-27 20:25:20','2024-12-27 20:25:20'),
('abb60aa6-207d-4845-9d9a-44d41f0857e0','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:52:23','2025-01-09 15:52:23'),
('aec6a39c-bf7f-480c-a380-f7fafbe02300','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00001<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/portal\\/invoices\\/1\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":1,\"invoice_number\":\"INV-00001\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"17 Dez 2024\",\"invoice_due_date\":\"17 Dez 2024\",\"status\":\"sent\"}',NULL,'2024-12-18 22:10:22','2024-12-18 22:10:22'),
('b006a0a7-c943-4b86-8fd5-c9b2b23c5205','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00001<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/portal\\/invoices\\/1\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":1,\"invoice_number\":\"INV-00001\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"17 Dez 2024\",\"invoice_due_date\":\"17 Dez 2024\",\"status\":\"sent\"}',NULL,'2024-12-18 21:13:48','2024-12-18 21:13:48'),
('b0682b41-2d3d-4ef8-9439-657c6713a683','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:35:52','2025-01-09 15:35:52'),
('b22ebc08-c321-4cb0-8004-2fe747463de1','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00001<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/portal\\/invoices\\/1\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":1,\"invoice_number\":\"INV-00001\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"17 Dez 2024\",\"invoice_due_date\":\"17 Dez 2024\",\"status\":\"sent\"}',NULL,'2024-12-18 21:42:44','2024-12-18 21:42:44'),
('b27bc32d-ecc9-470e-8983-082a7eba777d','App\\Notifications\\Sale\\Invoice','users',3,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00008<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/8\\\">click here<\\/a> to see the details.\",\"invoice_id\":8,\"invoice_number\":\"INV-00008\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"draft\"}',NULL,'2025-01-20 19:35:00','2025-01-20 19:35:00'),
('b4745dfd-eb5e-479e-b20f-60a5edf2e37e','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:44:04','2024-12-21 16:44:04'),
('b5208382-07a4-4f5d-9fc7-22273e2532d1','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00001<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/portal\\/invoices\\/1\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":1,\"invoice_number\":\"INV-00001\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"17 Dez 2024\",\"invoice_due_date\":\"17 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-18 19:16:38','2024-12-18 19:16:38'),
('ba99d236-6338-482b-a4a3-05ff2ad166c7','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00003<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/3\\\">click here<\\/a> to see the details.\",\"invoice_id\":3,\"invoice_number\":\"INV-00003\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:03:25','2024-12-21 16:03:25'),
('bda3341a-a144-495c-801f-998c0b253b17','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:26:55','2025-01-09 15:26:55'),
('bee9f2d4-20e5-4928-b8bf-82da65f6aaa3','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:33:01','2025-01-09 15:33:01'),
('c4bf8b2d-a1eb-42c8-b183-6dc6b19fa8e0','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00008<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/8\\\">click here<\\/a> to see the details.\",\"invoice_id\":8,\"invoice_number\":\"INV-00008\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"draft\"}',NULL,'2025-01-20 19:14:16','2025-01-20 19:14:16'),
('c7dffa80-40ce-4ef8-82cd-953c97297df5','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00009<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/portal\\/invoices\\/9\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":9,\"invoice_number\":\"INV-00009\",\"customer_name\":\"Flyermeyer\",\"amount\":476,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"draft\"}',NULL,'2025-01-20 21:28:57','2025-01-20 21:28:57'),
('c8243708-6965-4fa8-bc8c-2d27471583de','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00009<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/9\\\">click here<\\/a> to see the details.\",\"invoice_id\":9,\"invoice_number\":\"INV-00009\",\"customer_name\":\"Flyermeyer\",\"amount\":476,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"draft\"}',NULL,'2025-01-20 19:50:11','2025-01-20 19:50:11'),
('c87cecba-461f-459f-95e2-818305028c69','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:44:02','2025-01-09 15:44:02'),
('c9674ced-2424-4cdb-9c3c-c352f4764ee7','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00003<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/3\\\">click here<\\/a> to see the details.\",\"invoice_id\":3,\"invoice_number\":\"INV-00003\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 15:58:49','2024-12-21 15:58:49'),
('cf5b6a8a-b1fe-4585-a097-80df9061168e','App\\Notifications\\Sale\\Invoice','users',3,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00008<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/8\\\">click here<\\/a> to see the details.\",\"invoice_id\":8,\"invoice_number\":\"INV-00008\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"draft\"}',NULL,'2025-01-20 19:05:30','2025-01-20 19:05:30'),
('dd80107e-63ef-4159-a101-edd5fcbbe9c5','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:40:55','2025-01-09 15:40:55'),
('deff5693-e881-4ea3-ba41-7eebe8c791ad','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00001<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/portal\\/invoices\\/1\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":1,\"invoice_number\":\"INV-00001\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"17 Dez 2024\",\"invoice_due_date\":\"17 Dez 2024\",\"status\":\"sent\"}',NULL,'2024-12-18 21:28:12','2024-12-18 21:28:12'),
('df6a2e86-38b1-4945-8753-81811bd609bb','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00009<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/9\\\">click here<\\/a> to see the details.\",\"invoice_id\":9,\"invoice_number\":\"INV-00009\",\"customer_name\":\"Flyermeyer\",\"amount\":476,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"draft\"}',NULL,'2025-01-20 21:22:54','2025-01-20 21:22:54'),
('e28808e8-970e-45c1-a50c-7afc3ab860d5','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00003<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/3\\\">click here<\\/a> to see the details.\",\"invoice_id\":3,\"invoice_number\":\"INV-00003\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:13:35','2024-12-21 16:13:35'),
('e5d6c424-0e00-46a3-94d3-3d430155ca89','App\\Notifications\\Sale\\Invoice','App\\Models\\Common\\Contact',1,'{\"template_alias\":\"invoice_new_customer\",\"title\":\"New Invoice\",\"description\":\"<strong>INV-00001<\\/strong> invoice is created. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/portal\\/invoices\\/1\\\">click here<\\/a> to see the details and proceed with the payment.\",\"invoice_id\":1,\"invoice_number\":\"INV-00001\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"17 Dez 2024\",\"invoice_due_date\":\"17 Dez 2024\",\"status\":\"sent\"}',NULL,'2024-12-18 21:08:44','2024-12-18 21:08:44'),
('ed24b46d-047a-44a9-8e12-b7c0c529936b','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00003<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/3\\\">click here<\\/a> to see the details.\",\"invoice_id\":3,\"invoice_number\":\"INV-00003\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:06:54','2024-12-21 16:06:54'),
('ed7c916a-ab47-43bc-8742-1b8932a39b9e','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-20 17:02:47','2024-12-20 17:02:47'),
('f09ed045-a051-4c39-881b-9138eb1887b9','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00008<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/8\\\">click here<\\/a> to see the details.\",\"invoice_id\":8,\"invoice_number\":\"INV-00008\",\"customer_name\":\"Flyermeyer\",\"amount\":238,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"draft\"}',NULL,'2025-01-20 19:35:00','2025-01-20 19:35:00'),
('f21441ad-43ff-46f3-abbc-027c244b8558','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00003<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/3\\\">click here<\\/a> to see the details.\",\"invoice_id\":3,\"invoice_number\":\"INV-00003\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:15:01','2024-12-21 16:15:01'),
('f299a346-cdd7-4f43-8a86-0b4efd593159','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:57:15','2025-01-09 15:57:15'),
('f69bffe3-869e-490e-84af-dadfc6f17230','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00003<\\/strong> invoice. You can <a href=\\\"https:\\/\\/accounting.mk-pages.com\\/1\\/sales\\/invoices\\/3\\\">click here<\\/a> to see the details.\",\"invoice_id\":3,\"invoice_number\":\"INV-00003\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"19 Dez 2024\",\"invoice_due_date\":\"26 Dez 2024\",\"status\":\"draft\"}',NULL,'2024-12-21 16:22:52','2024-12-21 16:22:52'),
('f87c5e19-eb61-4108-a518-1c1aa6ce4ea4','App\\Notifications\\Sale\\Invoice','users',3,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00009<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/9\\\">click here<\\/a> to see the details.\",\"invoice_id\":9,\"invoice_number\":\"INV-00009\",\"customer_name\":\"Flyermeyer\",\"amount\":476,\"invoiced_date\":\"20 Jan 2025\",\"invoice_due_date\":\"27 Jan 2025\",\"status\":\"draft\"}',NULL,'2025-01-20 21:22:54','2025-01-20 21:22:54'),
('fdb9c154-4f2a-4057-925d-fae618aecd86','App\\Notifications\\Sale\\Invoice','users',1,'{\"template_alias\":\"invoice_view_admin\",\"title\":\"Invoice Viewed\",\"description\":\"<strong>Flyermeyer<\\/strong> has viewed the <strong>INV-00007<\\/strong> invoice. You can <a href=\\\"https:\\/\\/zugferd.mk-pages.com\\/1\\/sales\\/invoices\\/7\\\">click here<\\/a> to see the details.\",\"invoice_id\":7,\"invoice_number\":\"INV-00007\",\"customer_name\":\"Flyermeyer\",\"amount\":714,\"invoiced_date\":\"20 Dez 2024\",\"invoice_due_date\":\"27 Dez 2024\",\"status\":\"draft\"}',NULL,'2025-01-09 15:54:08','2025-01-09 15:54:08');
/*!40000 ALTER TABLE `tfb_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_password_resets`
--

DROP TABLE IF EXISTS `tfb_password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `tfb_password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_password_resets`
--

LOCK TABLES `tfb_password_resets` WRITE;
/*!40000 ALTER TABLE `tfb_password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tfb_password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_permissions`
--

DROP TABLE IF EXISTS `tfb_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `display_name` varchar(191) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfb_permissions_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_permissions`
--

LOCK TABLES `tfb_permissions` WRITE;
/*!40000 ALTER TABLE `tfb_permissions` DISABLE KEYS */;
INSERT INTO `tfb_permissions` VALUES
(1,'read-admin-panel','Read Admin Panel','Read Admin Panel','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(2,'read-api','Read Api','Read Api','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(3,'read-auth-profile','Read Auth Profile','Read Auth Profile','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(4,'update-auth-profile','Update Auth Profile','Update Auth Profile','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(5,'create-auth-users','Create Auth Users','Create Auth Users','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(6,'read-auth-users','Read Auth Users','Read Auth Users','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(7,'update-auth-users','Update Auth Users','Update Auth Users','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(8,'delete-auth-users','Delete Auth Users','Delete Auth Users','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(9,'create-banking-accounts','Create Banking Accounts','Create Banking Accounts','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(10,'read-banking-accounts','Read Banking Accounts','Read Banking Accounts','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(11,'update-banking-accounts','Update Banking Accounts','Update Banking Accounts','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(12,'delete-banking-accounts','Delete Banking Accounts','Delete Banking Accounts','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(13,'create-banking-reconciliations','Create Banking Reconciliations','Create Banking Reconciliations','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(14,'read-banking-reconciliations','Read Banking Reconciliations','Read Banking Reconciliations','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(15,'update-banking-reconciliations','Update Banking Reconciliations','Update Banking Reconciliations','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(16,'delete-banking-reconciliations','Delete Banking Reconciliations','Delete Banking Reconciliations','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(17,'create-banking-transactions','Create Banking Transactions','Create Banking Transactions','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(18,'read-banking-transactions','Read Banking Transactions','Read Banking Transactions','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(19,'update-banking-transactions','Update Banking Transactions','Update Banking Transactions','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(20,'delete-banking-transactions','Delete Banking Transactions','Delete Banking Transactions','2024-10-02 11:18:21','2024-10-02 11:18:21'),
(21,'create-banking-transfers','Create Banking Transfers','Create Banking Transfers','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(22,'read-banking-transfers','Read Banking Transfers','Read Banking Transfers','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(23,'update-banking-transfers','Update Banking Transfers','Update Banking Transfers','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(24,'delete-banking-transfers','Delete Banking Transfers','Delete Banking Transfers','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(25,'create-common-companies','Create Common Companies','Create Common Companies','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(26,'read-common-companies','Read Common Companies','Read Common Companies','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(27,'update-common-companies','Update Common Companies','Update Common Companies','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(28,'delete-common-companies','Delete Common Companies','Delete Common Companies','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(29,'create-common-dashboards','Create Common Dashboards','Create Common Dashboards','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(30,'read-common-dashboards','Read Common Dashboards','Read Common Dashboards','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(31,'update-common-dashboards','Update Common Dashboards','Update Common Dashboards','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(32,'delete-common-dashboards','Delete Common Dashboards','Delete Common Dashboards','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(33,'create-common-import','Create Common Import','Create Common Import','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(34,'create-common-items','Create Common Items','Create Common Items','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(35,'read-common-items','Read Common Items','Read Common Items','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(36,'update-common-items','Update Common Items','Update Common Items','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(37,'delete-common-items','Delete Common Items','Delete Common Items','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(38,'create-common-reports','Create Common Reports','Create Common Reports','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(39,'read-common-reports','Read Common Reports','Read Common Reports','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(40,'update-common-reports','Update Common Reports','Update Common Reports','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(41,'delete-common-reports','Delete Common Reports','Delete Common Reports','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(42,'read-common-search','Read Common Search','Read Common Search','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(43,'read-common-uploads','Read Common Uploads','Read Common Uploads','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(44,'delete-common-uploads','Delete Common Uploads','Delete Common Uploads','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(45,'create-common-widgets','Create Common Widgets','Create Common Widgets','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(46,'read-common-widgets','Read Common Widgets','Read Common Widgets','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(47,'update-common-widgets','Update Common Widgets','Update Common Widgets','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(48,'delete-common-widgets','Delete Common Widgets','Delete Common Widgets','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(49,'create-purchases-bills','Create Purchases Bills','Create Purchases Bills','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(50,'read-purchases-bills','Read Purchases Bills','Read Purchases Bills','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(51,'update-purchases-bills','Update Purchases Bills','Update Purchases Bills','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(52,'delete-purchases-bills','Delete Purchases Bills','Delete Purchases Bills','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(53,'create-purchases-vendors','Create Purchases Vendors','Create Purchases Vendors','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(54,'read-purchases-vendors','Read Purchases Vendors','Read Purchases Vendors','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(55,'update-purchases-vendors','Update Purchases Vendors','Update Purchases Vendors','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(56,'delete-purchases-vendors','Delete Purchases Vendors','Delete Purchases Vendors','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(57,'create-sales-customers','Create Sales Customers','Create Sales Customers','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(58,'read-sales-customers','Read Sales Customers','Read Sales Customers','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(59,'update-sales-customers','Update Sales Customers','Update Sales Customers','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(60,'delete-sales-customers','Delete Sales Customers','Delete Sales Customers','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(61,'create-sales-invoices','Create Sales Invoices','Create Sales Invoices','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(62,'read-sales-invoices','Read Sales Invoices','Read Sales Invoices','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(63,'update-sales-invoices','Update Sales Invoices','Update Sales Invoices','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(64,'delete-sales-invoices','Delete Sales Invoices','Delete Sales Invoices','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(65,'read-install-updates','Read Install Updates','Read Install Updates','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(66,'update-install-updates','Update Install Updates','Update Install Updates','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(67,'create-modules-api-key','Create Modules Api Key','Create Modules Api Key','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(68,'update-modules-api-key','Update Modules Api Key','Update Modules Api Key','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(69,'read-modules-home','Read Modules Home','Read Modules Home','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(70,'create-modules-item','Create Modules Item','Create Modules Item','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(71,'read-modules-item','Read Modules Item','Read Modules Item','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(72,'update-modules-item','Update Modules Item','Update Modules Item','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(73,'delete-modules-item','Delete Modules Item','Delete Modules Item','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(74,'read-modules-my','Read Modules My','Read Modules My','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(75,'read-modules-tiles','Read Modules Tiles','Read Modules Tiles','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(76,'read-notifications','Read Notifications','Read Notifications','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(77,'update-notifications','Update Notifications','Update Notifications','2024-10-02 11:18:22','2024-10-02 11:18:22'),
(78,'read-reports-expense-summary','Read Reports Expense Summary','Read Reports Expense Summary','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(79,'read-reports-income-summary','Read Reports Income Summary','Read Reports Income Summary','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(80,'read-reports-income-expense-summary','Read Reports Income Expense Summary','Read Reports Income Expense Summary','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(81,'read-reports-profit-loss','Read Reports Profit Loss','Read Reports Profit Loss','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(82,'read-reports-tax-summary','Read Reports Tax Summary','Read Reports Tax Summary','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(83,'create-settings-categories','Create Settings Categories','Create Settings Categories','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(84,'read-settings-categories','Read Settings Categories','Read Settings Categories','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(85,'update-settings-categories','Update Settings Categories','Update Settings Categories','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(86,'delete-settings-categories','Delete Settings Categories','Delete Settings Categories','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(87,'read-settings-company','Read Settings Company','Read Settings Company','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(88,'update-settings-company','Update Settings Company','Update Settings Company','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(89,'create-settings-currencies','Create Settings Currencies','Create Settings Currencies','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(90,'read-settings-currencies','Read Settings Currencies','Read Settings Currencies','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(91,'update-settings-currencies','Update Settings Currencies','Update Settings Currencies','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(92,'delete-settings-currencies','Delete Settings Currencies','Delete Settings Currencies','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(93,'read-settings-defaults','Read Settings Defaults','Read Settings Defaults','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(94,'update-settings-defaults','Update Settings Defaults','Update Settings Defaults','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(95,'read-settings-email','Read Settings Email','Read Settings Email','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(96,'update-settings-email','Update Settings Email','Update Settings Email','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(97,'read-settings-email-templates','Read Settings Email Templates','Read Settings Email Templates','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(98,'update-settings-email-templates','Update Settings Email Templates','Update Settings Email Templates','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(99,'read-settings-invoice','Read Settings Invoice','Read Settings Invoice','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(100,'update-settings-invoice','Update Settings Invoice','Update Settings Invoice','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(101,'read-settings-localisation','Read Settings Localisation','Read Settings Localisation','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(102,'update-settings-localisation','Update Settings Localisation','Update Settings Localisation','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(103,'read-settings-modules','Read Settings Modules','Read Settings Modules','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(104,'update-settings-modules','Update Settings Modules','Update Settings Modules','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(105,'read-settings-schedule','Read Settings Schedule','Read Settings Schedule','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(106,'update-settings-schedule','Update Settings Schedule','Update Settings Schedule','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(107,'create-settings-taxes','Create Settings Taxes','Create Settings Taxes','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(108,'read-settings-taxes','Read Settings Taxes','Read Settings Taxes','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(109,'update-settings-taxes','Update Settings Taxes','Update Settings Taxes','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(110,'delete-settings-taxes','Delete Settings Taxes','Delete Settings Taxes','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(111,'read-widgets-account-balance','Read Widgets Account Balance','Read Widgets Account Balance','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(112,'read-widgets-bank-feeds','Read Widgets Bank Feeds','Read Widgets Bank Feeds','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(113,'read-widgets-cash-flow','Read Widgets Cash Flow','Read Widgets Cash Flow','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(114,'read-widgets-currencies','Read Widgets Currencies','Read Widgets Currencies','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(115,'read-widgets-expenses-by-category','Read Widgets Expenses By Category','Read Widgets Expenses By Category','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(116,'read-widgets-payables','Read Widgets Payables','Read Widgets Payables','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(117,'read-widgets-profit-loss','Read Widgets Profit Loss','Read Widgets Profit Loss','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(118,'read-widgets-receivables','Read Widgets Receivables','Read Widgets Receivables','2024-10-02 11:18:23','2024-10-02 11:18:23'),
(119,'read-client-portal','Read Client Portal','Read Client Portal','2024-10-02 11:18:25','2024-10-02 11:18:25'),
(120,'read-portal-invoices','Read Portal Invoices','Read Portal Invoices','2024-10-02 11:18:25','2024-10-02 11:18:25'),
(121,'update-portal-invoices','Update Portal Invoices','Update Portal Invoices','2024-10-02 11:18:25','2024-10-02 11:18:25'),
(122,'read-portal-payments','Read Portal Payments','Read Portal Payments','2024-10-02 11:18:25','2024-10-02 11:18:25'),
(123,'update-portal-payments','Update Portal Payments','Update Portal Payments','2024-10-02 11:18:25','2024-10-02 11:18:25'),
(124,'read-portal-profile','Read Portal Profile','Read Portal Profile','2024-10-02 11:18:25','2024-10-02 11:18:25'),
(125,'update-portal-profile','Update Portal Profile','Update Portal Profile','2024-10-02 11:18:25','2024-10-02 11:18:25'),
(126,'read-offline-payments-settings','Read Offline-Zahlungen Settings','Read Offline-Zahlungen Settings','2024-10-02 12:18:49','2024-10-02 12:18:49'),
(127,'update-offline-payments-settings','Update Offline-Zahlungen Settings','Update Offline-Zahlungen Settings','2024-10-02 12:18:49','2024-10-02 12:18:49'),
(128,'delete-offline-payments-settings','Delete Offline-Zahlungen Settings','Delete Offline-Zahlungen Settings','2024-10-02 12:18:49','2024-10-02 12:18:49'),
(129,'read-paypal-standard-settings','Read PayPal Standard Settings','Read PayPal Standard Settings','2024-10-02 12:18:49','2024-10-02 12:18:49'),
(130,'update-paypal-standard-settings','Update PayPal Standard Settings','Update PayPal Standard Settings','2024-10-02 12:18:49','2024-10-02 12:18:49');
/*!40000 ALTER TABLE `tfb_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_personal_access_tokens`
--

DROP TABLE IF EXISTS `tfb_personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfb_personal_access_tokens_token_unique` (`token`),
  KEY `tfb_personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_personal_access_tokens`
--

LOCK TABLES `tfb_personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `tfb_personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tfb_personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_reconciliations`
--

DROP TABLE IF EXISTS `tfb_reconciliations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_reconciliations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `started_at` datetime NOT NULL,
  `ended_at` datetime NOT NULL,
  `closing_balance` double(15,4) NOT NULL DEFAULT 0.0000,
  `transactions` text DEFAULT NULL,
  `reconciled` tinyint(1) NOT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_reconciliations_company_id_index` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_reconciliations`
--

LOCK TABLES `tfb_reconciliations` WRITE;
/*!40000 ALTER TABLE `tfb_reconciliations` DISABLE KEYS */;
/*!40000 ALTER TABLE `tfb_reconciliations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_recurring`
--

DROP TABLE IF EXISTS `tfb_recurring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_recurring` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `recurable_type` varchar(191) NOT NULL,
  `recurable_id` bigint(20) unsigned NOT NULL,
  `frequency` varchar(191) NOT NULL,
  `interval` int(11) NOT NULL DEFAULT 1,
  `started_at` datetime NOT NULL,
  `status` varchar(191) NOT NULL DEFAULT 'active',
  `limit_by` varchar(191) NOT NULL DEFAULT 'count',
  `limit_count` int(11) NOT NULL DEFAULT 0,
  `limit_date` datetime DEFAULT NULL,
  `auto_send` tinyint(1) NOT NULL DEFAULT 1,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_recurring_recurable_type_recurable_id_index` (`recurable_type`,`recurable_id`),
  KEY `tfb_recurring_company_id_index` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_recurring`
--

LOCK TABLES `tfb_recurring` WRITE;
/*!40000 ALTER TABLE `tfb_recurring` DISABLE KEYS */;
/*!40000 ALTER TABLE `tfb_recurring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_reports`
--

DROP TABLE IF EXISTS `tfb_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_reports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `class` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `description` text NOT NULL,
  `settings` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_reports_company_id_index` (`company_id`),
  KEY `tfb_reports_class_index` (`class`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_reports`
--

LOCK TABLES `tfb_reports` WRITE;
/*!40000 ALTER TABLE `tfb_reports` DISABLE KEYS */;
INSERT INTO `tfb_reports` VALUES
(1,1,'App\\Reports\\IncomeSummary','Einnahmenübersicht','Monatliche Zusammenfassung der Einnahmen nach Kategorie.','{\"group\":\"category\",\"period\":\"monthly\",\"basis\":\"accrual\"}',NULL,'core::seed','2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(2,1,'App\\Reports\\ExpenseSummary','Ausgabenübersicht','Monatliche Zusammenfassung der Ausgaben nach Kategorie.','{\"group\":\"category\",\"period\":\"monthly\",\"basis\":\"accrual\"}',NULL,'core::seed','2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(3,1,'App\\Reports\\IncomeExpenseSummary','Einnahmen / Ausgaben','Monatlicher Vergleich Einnahmen / Ausgaben nach Kategorie.','{\"group\":\"category\",\"period\":\"monthly\",\"basis\":\"accrual\"}',NULL,'core::seed','2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(4,1,'App\\Reports\\ProfitLoss','Gewinn & Verlust','Quartalsweise Gewinn & Verlust nach Kategorie.','{\"group\":\"category\",\"period\":\"quarterly\",\"basis\":\"accrual\"}',NULL,'core::seed','2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(5,1,'App\\Reports\\TaxSummary','Steuerzusammenfassung','Vierteljährliche Steuerzusammenfassung.','{\"period\":\"quarterly\",\"basis\":\"accrual\"}',NULL,'core::seed','2024-10-02 12:18:49','2024-10-02 12:18:49',NULL);
/*!40000 ALTER TABLE `tfb_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_role_permissions`
--

DROP TABLE IF EXISTS `tfb_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_role_permissions` (
  `role_id` int(10) unsigned NOT NULL,
  `permission_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `tfb_role_permissions_permission_id_foreign` (`permission_id`),
  CONSTRAINT `tfb_role_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `tfb_permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tfb_role_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `tfb_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_role_permissions`
--

LOCK TABLES `tfb_role_permissions` WRITE;
/*!40000 ALTER TABLE `tfb_role_permissions` DISABLE KEYS */;
INSERT INTO `tfb_role_permissions` VALUES
(1,1),
(1,2),
(1,3),
(1,4),
(1,5),
(1,6),
(1,7),
(1,8),
(1,9),
(1,10),
(1,11),
(1,12),
(1,13),
(1,14),
(1,15),
(1,16),
(1,17),
(1,18),
(1,19),
(1,20),
(1,21),
(1,22),
(1,23),
(1,24),
(1,25),
(1,26),
(1,27),
(1,28),
(1,29),
(1,30),
(1,31),
(1,32),
(1,33),
(1,34),
(1,35),
(1,36),
(1,37),
(1,38),
(1,39),
(1,40),
(1,41),
(1,42),
(1,43),
(1,44),
(1,45),
(1,46),
(1,47),
(1,48),
(1,49),
(1,50),
(1,51),
(1,52),
(1,53),
(1,54),
(1,55),
(1,56),
(1,57),
(1,58),
(1,59),
(1,60),
(1,61),
(1,62),
(1,63),
(1,64),
(1,65),
(1,66),
(1,67),
(1,68),
(1,69),
(1,70),
(1,71),
(1,72),
(1,73),
(1,74),
(1,75),
(1,76),
(1,77),
(1,78),
(1,79),
(1,80),
(1,81),
(1,82),
(1,83),
(1,84),
(1,85),
(1,86),
(1,87),
(1,88),
(1,89),
(1,90),
(1,91),
(1,92),
(1,93),
(1,94),
(1,95),
(1,96),
(1,97),
(1,98),
(1,99),
(1,100),
(1,101),
(1,102),
(1,103),
(1,104),
(1,105),
(1,106),
(1,107),
(1,108),
(1,109),
(1,110),
(1,111),
(1,112),
(1,113),
(1,114),
(1,115),
(1,116),
(1,117),
(1,118),
(1,126),
(1,127),
(1,128),
(1,129),
(1,130),
(2,1),
(2,3),
(2,4),
(2,9),
(2,10),
(2,11),
(2,12),
(2,13),
(2,14),
(2,15),
(2,16),
(2,17),
(2,18),
(2,19),
(2,20),
(2,21),
(2,22),
(2,23),
(2,24),
(2,25),
(2,26),
(2,27),
(2,28),
(2,29),
(2,30),
(2,31),
(2,32),
(2,33),
(2,34),
(2,35),
(2,36),
(2,37),
(2,38),
(2,39),
(2,40),
(2,41),
(2,42),
(2,43),
(2,45),
(2,46),
(2,47),
(2,48),
(2,49),
(2,50),
(2,51),
(2,52),
(2,53),
(2,54),
(2,55),
(2,56),
(2,57),
(2,58),
(2,59),
(2,60),
(2,61),
(2,62),
(2,63),
(2,64),
(2,65),
(2,66),
(2,76),
(2,77),
(2,78),
(2,79),
(2,80),
(2,81),
(2,82),
(2,83),
(2,84),
(2,85),
(2,86),
(2,87),
(2,88),
(2,89),
(2,90),
(2,91),
(2,92),
(2,93),
(2,94),
(2,95),
(2,96),
(2,97),
(2,98),
(2,99),
(2,100),
(2,101),
(2,102),
(2,103),
(2,104),
(2,105),
(2,106),
(2,107),
(2,108),
(2,109),
(2,110),
(2,111),
(2,112),
(2,113),
(2,114),
(2,115),
(2,116),
(2,117),
(2,118),
(2,126),
(2,127),
(2,128),
(2,129),
(2,130),
(3,119),
(3,120),
(3,121),
(3,122),
(3,123),
(3,124),
(3,125),
(4,1),
(4,2),
(4,3),
(4,4),
(4,10),
(4,14),
(4,18),
(4,22),
(4,30),
(4,35),
(4,39),
(4,50),
(4,54),
(4,58),
(4,62),
(4,69),
(4,71),
(4,74),
(4,75),
(4,78),
(4,79),
(4,80),
(4,81),
(4,82),
(4,111),
(4,112),
(4,113),
(4,114),
(4,115),
(4,116),
(4,117),
(4,118);
/*!40000 ALTER TABLE `tfb_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_roles`
--

DROP TABLE IF EXISTS `tfb_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `display_name` varchar(191) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfb_roles_name_unique` (`name`),
  KEY `tfb_roles_name_index` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_roles`
--

LOCK TABLES `tfb_roles` WRITE;
/*!40000 ALTER TABLE `tfb_roles` DISABLE KEYS */;
INSERT INTO `tfb_roles` VALUES
(1,'admin','Admin','Sie erhalten vollen Zugriff auf Akaunting, einschließlich Kunden, Rechnungen, Berichte, Einstellungen und Apps.',NULL,NULL,'2024-10-02 11:18:21','2024-10-02 11:18:21'),
(2,'manager','Manager','Sie erhalten vollen Zugriff auf Akaunting, können aber keine Benutzer und Apps verwalten.',NULL,NULL,'2024-10-02 11:18:23','2024-10-02 11:18:23'),
(3,'customer','Kunde','Sie können auf das Kundenportal zugreifen und ihre Rechnungen online über die Zahlungsmethoden, die Sie eingerichtet haben, bezahlen.',NULL,NULL,'2024-10-02 11:18:25','2024-10-02 11:18:25'),
(4,'accountant','Buchhalter','Sie können auf Rechnungen, Transaktionen, Berichte und Journaleinträge zugreifen.',NULL,NULL,'2024-10-02 11:18:25','2024-10-02 11:18:25');
/*!40000 ALTER TABLE `tfb_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_sessions`
--

DROP TABLE IF EXISTS `tfb_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_sessions` (
  `id` varchar(191) NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `tfb_sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_sessions`
--

LOCK TABLES `tfb_sessions` WRITE;
/*!40000 ALTER TABLE `tfb_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tfb_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_settings`
--

DROP TABLE IF EXISTS `tfb_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `key` varchar(191) NOT NULL,
  `value` text DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfb_settings_company_id_key_deleted_at_unique` (`company_id`,`key`,`deleted_at`),
  KEY `tfb_settings_company_id_index` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_settings`
--

LOCK TABLES `tfb_settings` WRITE;
/*!40000 ALTER TABLE `tfb_settings` DISABLE KEYS */;
INSERT INTO `tfb_settings` VALUES
(1,1,'invoice.title','Rechnung',NULL),
(2,1,'default.locale','de-DE',NULL),
(3,1,'default.account','1',NULL),
(4,1,'default.income_category','2',NULL),
(5,1,'default.expense_category','4',NULL),
(6,1,'wizard.completed','1',NULL),
(7,1,'offline-payments.methods','[{\"code\":\"offline-payments.cash.1\",\"name\":\"Bargeld\",\"customer\":\"0\",\"order\":\"1\",\"description\":null},{\"code\":\"offline-payments.bank_transfer.2\",\"name\":\"Bank\\u00fcberweisung\",\"customer\":\"0\",\"order\":\"2\",\"description\":null}]',NULL),
(8,1,'company.name','Winter Hausmeisterdienst',NULL),
(9,1,'company.email','winter.hausmeisterdienst@t-online.de',NULL),
(10,1,'company.address','Holzleite 27',NULL),
(11,1,'company.country','DE',NULL),
(12,1,'apps.api_key','38aa3b2c-57f8-44f3-b43f-aacb453dad4a',NULL),
(13,1,'default.currency','EUR',NULL),
(14,1,'localisation.timezone','Europe/Berlin',NULL),
(15,1,'invoice.hide_item_description','0',NULL),
(16,1,'invoice.hide_amount','0',NULL),
(17,1,'invoice.color','gray-400',NULL),
(18,1,'invoice._template','default',NULL),
(19,1,'invoice.message_name_or_description_required','Ihre Rechnung muss einen Wert für entweder <b>Name</b> oder <b>Beschreibung</b> enthalten.',NULL),
(20,1,'invoice.temp_payment_term','7',NULL),
(22,1,'default.payment_method','offline-payments.bank_transfer.2',NULL),
(23,1,'default.address_format','{city}, {state} {zip_code} \r\n{country}',NULL),
(24,1,'default.tax','1',NULL),
(25,1,'company.phone','091336076551',NULL),
(26,1,'company.tax_number','217/288/80020',NULL),
(27,1,'company.city','Effeltrich',NULL),
(28,1,'company.zip_code','91090',NULL),
(29,1,'company.state','Bayern',NULL),
(30,1,'company.logo','3',NULL),
(31,1,'invoice.footer','Bankverbindungen\r\nStadt- und Kreissparkasse Erlangen\r\nIBAN DE66 7635 0000 0026 0055 77\r\nBIC/Swift BYLADEM1ERH',NULL),
(32,1,'invoice.payment_terms','7',NULL),
(33,1,'transaction.number_next','3',NULL),
(35,1,'email.protocol','smtp',NULL),
(36,1,'email.smtp_host','mail.your-server.de',NULL),
(37,1,'email.smtp_port','587',NULL),
(38,1,'email.smtp_username','matthias@mk-pages.com',NULL),
(39,1,'email.smtp_password','Matze1357!',NULL),
(40,1,'email.smtp_encryption','tls',NULL),
(41,1,'invoice.number_prefix','2025-',NULL),
(42,1,'invoice.number_next','2',NULL);
/*!40000 ALTER TABLE `tfb_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_taxes`
--

DROP TABLE IF EXISTS `tfb_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_taxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `rate` double(15,4) NOT NULL,
  `type` varchar(191) NOT NULL DEFAULT 'normal',
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_taxes_company_id_index` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_taxes`
--

LOCK TABLES `tfb_taxes` WRITE;
/*!40000 ALTER TABLE `tfb_taxes` DISABLE KEYS */;
INSERT INTO `tfb_taxes` VALUES
(1,1,'Umsatzsteuer',19.0000,'normal',1,'core::ui',1,'2024-12-17 22:46:29','2024-12-17 22:46:29',NULL);
/*!40000 ALTER TABLE `tfb_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_transaction_taxes`
--

DROP TABLE IF EXISTS `tfb_transaction_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_transaction_taxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(10) unsigned NOT NULL,
  `type` varchar(191) NOT NULL,
  `transaction_id` int(10) unsigned NOT NULL,
  `tax_id` int(10) unsigned NOT NULL,
  `name` varchar(191) NOT NULL,
  `amount` double(15,4) NOT NULL DEFAULT 0.0000,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_transaction_taxes_company_id_index` (`company_id`),
  KEY `tfb_transaction_taxes_type_index` (`type`),
  KEY `tfb_transaction_taxes_transaction_id_index` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_transaction_taxes`
--

LOCK TABLES `tfb_transaction_taxes` WRITE;
/*!40000 ALTER TABLE `tfb_transaction_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tfb_transaction_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_transactions`
--

DROP TABLE IF EXISTS `tfb_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `type` varchar(191) NOT NULL,
  `number` varchar(191) NOT NULL,
  `paid_at` datetime NOT NULL,
  `amount` double(15,4) NOT NULL,
  `currency_code` varchar(191) NOT NULL,
  `currency_rate` double(15,8) NOT NULL,
  `account_id` int(11) NOT NULL,
  `document_id` int(11) DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `category_id` int(11) NOT NULL DEFAULT 1,
  `description` text DEFAULT NULL,
  `payment_method` varchar(191) NOT NULL,
  `reference` varchar(191) DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `split_id` int(10) unsigned DEFAULT NULL,
  `reconciled` tinyint(1) NOT NULL DEFAULT 0,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_transactions_company_id_type_index` (`company_id`,`type`),
  KEY `tfb_transactions_account_id_index` (`account_id`),
  KEY `tfb_transactions_category_id_index` (`category_id`),
  KEY `tfb_transactions_contact_id_index` (`contact_id`),
  KEY `tfb_transactions_document_id_index` (`document_id`),
  KEY `tfb_transactions_split_id_foreign` (`split_id`),
  KEY `tfb_transactions_number_index` (`number`),
  CONSTRAINT `tfb_transactions_split_id_foreign` FOREIGN KEY (`split_id`) REFERENCES `tfb_transactions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_transactions`
--

LOCK TABLES `tfb_transactions` WRITE;
/*!40000 ALTER TABLE `tfb_transactions` DISABLE KEYS */;
INSERT INTO `tfb_transactions` VALUES
(1,1,'income','TRA-00001','2024-12-19 00:34:28',238.0000,'EUR',1.00000000,1,1,1,2,NULL,'offline-payments.bank_transfer.2',NULL,0,NULL,0,'core::ui',1,'2024-12-18 23:34:28','2025-01-20 18:58:38','2025-01-20 18:58:38'),
(2,1,'income','TRA-00002','2024-12-19 13:18:57',238.0000,'EUR',1.00000000,1,5,1,2,NULL,'offline-payments.bank_transfer.2',NULL,0,NULL,0,'core::ui',1,'2024-12-19 12:18:57','2025-01-20 18:58:38','2025-01-20 18:58:38');
/*!40000 ALTER TABLE `tfb_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_transfers`
--

DROP TABLE IF EXISTS `tfb_transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_transfers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `expense_transaction_id` int(11) NOT NULL,
  `income_transaction_id` int(11) NOT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_transfers_company_id_index` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_transfers`
--

LOCK TABLES `tfb_transfers` WRITE;
/*!40000 ALTER TABLE `tfb_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `tfb_transfers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_user_companies`
--

DROP TABLE IF EXISTS `tfb_user_companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_user_companies` (
  `user_id` int(10) unsigned NOT NULL,
  `company_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`company_id`),
  KEY `tfb_user_companies_user_id_index` (`user_id`),
  KEY `tfb_user_companies_company_id_index` (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_user_companies`
--

LOCK TABLES `tfb_user_companies` WRITE;
/*!40000 ALTER TABLE `tfb_user_companies` DISABLE KEYS */;
INSERT INTO `tfb_user_companies` VALUES
(1,1),
(3,1);
/*!40000 ALTER TABLE `tfb_user_companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_user_dashboards`
--

DROP TABLE IF EXISTS `tfb_user_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_user_dashboards` (
  `user_id` int(10) unsigned NOT NULL,
  `dashboard_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`dashboard_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_user_dashboards`
--

LOCK TABLES `tfb_user_dashboards` WRITE;
/*!40000 ALTER TABLE `tfb_user_dashboards` DISABLE KEYS */;
INSERT INTO `tfb_user_dashboards` VALUES
(1,1),
(3,3);
/*!40000 ALTER TABLE `tfb_user_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_user_invitations`
--

DROP TABLE IF EXISTS `tfb_user_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_user_invitations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_user_invitations`
--

LOCK TABLES `tfb_user_invitations` WRITE;
/*!40000 ALTER TABLE `tfb_user_invitations` DISABLE KEYS */;
INSERT INTO `tfb_user_invitations` VALUES
(2,3,'9ca92a8e-560f-4197-b4ce-caf26c135925','core::ui',1,'2025-01-02 20:43:19','2025-01-02 19:45:01','2025-01-02 19:45:01');
/*!40000 ALTER TABLE `tfb_user_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_user_permissions`
--

DROP TABLE IF EXISTS `tfb_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_user_permissions` (
  `user_id` int(10) unsigned NOT NULL,
  `permission_id` int(10) unsigned NOT NULL,
  `user_type` varchar(191) NOT NULL,
  PRIMARY KEY (`user_id`,`permission_id`,`user_type`),
  KEY `tfb_user_permissions_permission_id_foreign` (`permission_id`),
  CONSTRAINT `tfb_user_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `tfb_permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_user_permissions`
--

LOCK TABLES `tfb_user_permissions` WRITE;
/*!40000 ALTER TABLE `tfb_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tfb_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_user_roles`
--

DROP TABLE IF EXISTS `tfb_user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_user_roles` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  KEY `tfb_user_roles_user_id_index` (`user_id`),
  KEY `tfb_user_roles_role_id_index` (`role_id`),
  CONSTRAINT `tfb_user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `tfb_roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_user_roles`
--

LOCK TABLES `tfb_user_roles` WRITE;
/*!40000 ALTER TABLE `tfb_user_roles` DISABLE KEYS */;
INSERT INTO `tfb_user_roles` VALUES
(1,1),
(3,2);
/*!40000 ALTER TABLE `tfb_user_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_users`
--

DROP TABLE IF EXISTS `tfb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `last_logged_in_at` timestamp NULL DEFAULT NULL,
  `locale` varchar(191) NOT NULL DEFAULT 'de-DE',
  `landing_page` varchar(70) DEFAULT 'dashboard',
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tfb_users_email_deleted_at_unique` (`email`,`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_users`
--

LOCK TABLES `tfb_users` WRITE;
/*!40000 ALTER TABLE `tfb_users` DISABLE KEYS */;
INSERT INTO `tfb_users` VALUES
(1,'','matthias@mk-pages.com','$2y$10$TBrPQeL7/hdGMfLxoSGdb.wMyxoiuV/NlSOhTGTjL0ZXWdVEnPas2','fyqGnDrKJ2ULQ2x470QT6WrJwGOVhHNXEA1kh29aESYXiU3um5tsnBuvIfUe','2025-01-20 17:56:35','de-DE','dashboard',1,'core::ui',NULL,'2024-10-02 12:18:49','2025-01-20 17:56:35',NULL),
(3,'Matthias Klement','info@mk-pages.com','$2y$10$UduQC1y3CZHG97CcOkQ3SerHciqmI/gUs2FiCjP39LQW4RbMHPPZW','abnDCumgg1H798qwZY7g7Q1LxSU7Va013ggBp8TZuwu4UQUxDGptz5coNzct','2025-01-20 21:10:10','de-DE','dashboard',1,'core::ui',1,'2025-01-02 20:43:19','2025-01-20 21:10:10',NULL);
/*!40000 ALTER TABLE `tfb_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tfb_widgets`
--

DROP TABLE IF EXISTS `tfb_widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tfb_widgets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `dashboard_id` int(11) NOT NULL,
  `class` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT 0,
  `settings` text DEFAULT NULL,
  `created_from` varchar(100) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tfb_widgets_company_id_dashboard_id_index` (`company_id`,`dashboard_id`),
  KEY `tfb_widgets_class_index` (`class`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tfb_widgets`
--

LOCK TABLES `tfb_widgets` WRITE;
/*!40000 ALTER TABLE `tfb_widgets` DISABLE KEYS */;
INSERT INTO `tfb_widgets` VALUES
(1,1,1,'App\\Widgets\\Receivables','Forderungen',1,'{\"width\":\"50\"}','core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(2,1,1,'App\\Widgets\\Payables','Verbindlichkeiten',2,'{\"width\":\"50\"}','core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(3,1,1,'App\\Widgets\\CashFlow','Umlaufvermögen',3,'{\"width\":\"100\"}','core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(4,1,1,'App\\Widgets\\ProfitLoss','Gewinn & Verlust',4,'{\"width\":\"50\"}','core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(5,1,1,'App\\Widgets\\ExpensesByCategory','Ausgaben nach Kategorie',5,'{\"width\":\"50\"}','core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(6,1,1,'App\\Widgets\\AccountBalance','Kontostand',6,'{\"width\":\"50\"}','core::seed',NULL,'2024-10-02 12:18:49','2024-12-18 23:25:31','2024-12-18 23:25:31'),
(7,1,1,'App\\Widgets\\BankFeeds','Bankkonten verbinden',7,'{\"width\":\"50\"}','core::seed',NULL,'2024-10-02 12:18:49','2024-10-02 12:18:49',NULL),
(15,1,3,'App\\Widgets\\Receivables','Forderungen',1,'{\"width\":\"50\"}','core::seed',1,'2025-01-02 20:43:19','2025-01-02 20:43:19',NULL),
(16,1,3,'App\\Widgets\\Payables','Verbindlichkeiten',2,'{\"width\":\"50\"}','core::seed',1,'2025-01-02 20:43:19','2025-01-02 20:43:19',NULL),
(17,1,3,'App\\Widgets\\CashFlow','Umlaufvermögen',3,'{\"width\":\"100\"}','core::seed',1,'2025-01-02 20:43:19','2025-01-02 20:43:19',NULL),
(18,1,3,'App\\Widgets\\ProfitLoss','Gewinn & Verlust',4,'{\"width\":\"50\"}','core::seed',1,'2025-01-02 20:43:19','2025-01-02 20:43:19',NULL),
(19,1,3,'App\\Widgets\\ExpensesByCategory','Ausgaben nach Kategorie',5,'{\"width\":\"50\"}','core::seed',1,'2025-01-02 20:43:19','2025-01-02 20:43:19',NULL),
(20,1,3,'App\\Widgets\\AccountBalance','Kontostand',6,'{\"width\":\"50\"}','core::seed',1,'2025-01-02 20:43:19','2025-01-02 20:43:19',NULL),
(21,1,3,'App\\Widgets\\BankFeeds','Bankkonten verbinden',7,'{\"width\":\"50\"}','core::seed',1,'2025-01-02 20:43:19','2025-01-02 20:43:19',NULL);
/*!40000 ALTER TABLE `tfb_widgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'zugferd'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-20 22:57:57
