<?php

return [

    'version'               => 'Versiya',
    'powered'               => 'Akaunting tərəfindən',
    'link'                  => 'https://akaunting.com/tr',
    'software'              => 'Pulsuz Ön Muhasibat Proqramı',

];
