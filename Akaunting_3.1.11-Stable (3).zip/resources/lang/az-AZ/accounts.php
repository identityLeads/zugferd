<?php

return [

    'account_name'          => 'Hesab adı',
    'number'                => 'Nömrə',
    'opening_balance'       => 'Açılış balansı',
    'current_balance'       => 'Mövcud balans',
    'bank_name'             => 'Bank adı',
    'bank_phone'            => 'Bank telefonu',
    'bank_address'          => 'Bank ünvanı',
    'default_account'       => 'İlkin hesab',

];
