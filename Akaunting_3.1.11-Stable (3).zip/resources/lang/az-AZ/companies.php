<?php

return [

    'domain'                => 'Domen',
    'logo'                  => 'Loqo',

    'error' => [
        'not_user_company'  => 'Xəta: Bu şirkəti dəyişdirmə icazəniz yoxdur!',
        'delete_active'     => 'Xəta: Aktiv şirkəti silə bilməzsiniz. Zəhmət olmasa əvvəlcə başqa bir şirkətə keçin!',
        'disable_active'    => 'Xəta: Aktiv şirkəti sıradan çıxarda bilməzsiniz. Zəhmət olmasa əvvəlcə başqa bir şirkətə keçin!',
    ],

];
