<?php

return [

    'payment_made'      => 'Ödəniş edildi',
    'paid_to'           => 'Ödəniş göndərildi',
    'related_bill'      => 'Əlaqəli faktura',
    'create_payment'    => 'Ödəniş yarat',

];
