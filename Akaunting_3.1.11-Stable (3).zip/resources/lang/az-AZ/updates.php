<?php

return [

    'installed_version'     => 'Quraşdırılmış versiya',
    'latest_version'        => 'Son versiya',
    'update'                => ':version versiyasına yenilə',
    'changelog'             => 'Dəyişiklik Qeydi',
    'check'                 => 'Yenilə',
    'new_core'              => 'Akaunting\'in yeni bir versiyası mövcuddur.',
    'latest_core'           => 'Təbriklər! Akaunting\'in ən son versiyasına sahib oldunuz. Təhlükəsizlik yeniləmələri avtomatik olaraq yenilənəcəkdir.',
    'success'               => 'Yeniləmə əməliyyatı müvəffəqiyyətlə tamamlandı.',
    'error'                 => 'Yeniləmə əməliyyatı uğursuz oldu, zəhmət olmazsa yenidən cəhd edin.',

];
