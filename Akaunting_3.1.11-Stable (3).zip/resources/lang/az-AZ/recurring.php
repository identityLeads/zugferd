<?php

return [

    'recurring'             => 'Təkrarlanan',
    'every'                 => 'Hər',
    'period'                => 'Aralıq',
    'times'                 => 'Dəfə',
    'daily'                 => 'Günlük',
    'weekly'                => 'Həftəlik',
    'monthly'               => 'Aylı1',
    'yearly'                => 'İllik',
    'custom'                => 'Xüsusi',
    'days'                  => 'Gün',
    'weeks'                 => 'Həftə',
    'months'                => 'Ay',
    'years'                 => 'İl',
    'message'               => 'Bu təkrarlayan bir :type və bir sonrakı :type avtomatik olaraq :date tarixdə yaradılacaq.',

];
