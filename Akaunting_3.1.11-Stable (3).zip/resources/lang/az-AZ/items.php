<?php

return [

    'sale_price'            => 'Satış Qiyməti',
    'purchase_price'         => 'Alış Qiyməti',
    'enter_item_description' => 'Məhsul/Xidmət Açıqlamasını daxil edin',

];
