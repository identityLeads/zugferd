<?php

return [

    'reconcile'             => 'Razılaşma',
    'unreconcile'           => 'Razılaşmanı ləğv et',
    'reconciled'            => 'Razılaşdırıldı',
    'opening_balance'       => 'Açılış Balansı',
    'closing_balance'       => 'Bağlanma Balansı',
    'unreconciled'          => 'Razılaşma baş tutmadı',
    'transactions'          => 'Əməliyyatlar',
    'start_date'            => 'Başlanğıc Tarixi',
    'end_date'              => 'Bitiş Tarixi',
    'cleared_amount'        => 'Təmizlənmiş Məbləğ',
    'deposit'               => 'Əmanət edildi',
    'withdrawal'            => 'Çıxarılan',

];
