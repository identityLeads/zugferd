<?php

return [

    'rate'                  => 'Dərəcə',
    'rate_percent'          => 'Dərəcə (%)',
    'normal'                => 'Normal',
    'inclusive'             => 'Daxil',
    'compound'              => 'Qarışıq',
    'fixed'                 => 'Sabit',
    'withholding'           => 'Tutulma',
];
