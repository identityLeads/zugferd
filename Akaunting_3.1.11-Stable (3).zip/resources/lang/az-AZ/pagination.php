<?php

return [

    'previous'              => 'Geri',
    'next'                  => 'İləri',
    'showing'               => ':total qeyddən :first-:last arası.',
    'page'                  => 'səhifə başına.',
];
