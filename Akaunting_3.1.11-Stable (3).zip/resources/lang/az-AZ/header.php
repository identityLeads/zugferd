<?php

return [

    'change_language'       => 'Dil Dəyişdir',
    'last_login'            => 'Son giriş :time',
    'notifications' => [
        'counter'           => '{0} Bildiriş yox|{1} :count bildirişiniz var|[2,*] :count bildirişiniz var',
        'overdue_invoices'  => '{1} :count Gecikmiş Faktura Mövcuddur |[2,*] :count Gecikmiş Faktura Mövcuddur',
        'upcoming_bills'    => '{1} :count Yaxınlaşan Faktura Mövcuddur|[2,*] :count Yaxınlaşan Faktura Mövcuddur',
        'view_all'          => 'Hamısını göstər'
    ],
    'docs_link'             => 'https://akaunting.com/docs',
    'support_link'          => 'https://akaunting.com/support',

];
