<?php

return [

    'error' => [
        'not_user_dashboard'    => 'Xəta: Bu idarəetmə panelini dəyişdirmə icazəniz yoxdur!',
        'delete_last'           => 'Xəta: Son idarəetmə panelini silə bilməzsiniz. Əvvəlcə yeni bir panel yaradın!',
        'disable_last'          => 'Xəta: Son idarəetmə panelini sıradan çıxarda bilməzsiniz. Əvvəlcə yeni bir panel yaradın!',
    ],

];
