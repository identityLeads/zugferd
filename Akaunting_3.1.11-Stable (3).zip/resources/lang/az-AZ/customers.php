<?php

return [

    'can_login'             => 'Giriş edilə bilər?',
    'user_created'          => 'İstifadəçi yaradıldı',

    'error' => [
        'email'             => 'E-poçt ünvanı artıq istifadədədir.',
    ],

];
