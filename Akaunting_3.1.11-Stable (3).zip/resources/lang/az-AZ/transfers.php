<?php

return [

    'from_account'          => 'Göndərən Hesab',
    'to_account'            => 'Alan Hesab',

    'messages' => [
        'delete'            => ':from hesabından :to hesabına (:amount)',
    ],

];
