<?php

return [

    'title' => 'Pod održavanjem',

    'message' => 'Žao nam je, trenutno smo na održavanju. Molimo pokušajte ponovo kasnije!',

    'read_only' => 'Omogućen je samo režim za čitanje. Dozvoljen vam je pregled, ali ništa ne možete mijenjati!',

];
