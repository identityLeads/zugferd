<?php

return [

    'revenue_received'      => 'Primljeni prihod',
    'paid_by'               => 'Uplaceno od',
    'related_invoice'       => 'Vezane fakture',
    'create_revenue'        => 'Kreiraj prihod',

];
