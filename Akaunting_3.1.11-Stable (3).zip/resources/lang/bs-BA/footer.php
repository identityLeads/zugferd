<?php

return [

    'version'               => 'Verzija',
    'powered'               => 'Omogućeno od Akaunting',
    'link'                  => 'https://akaunting.com',
    'software'              => 'Besplatan web finansijski softver',
    'powered_by'            => 'Autor',
    'tag_line'              => 'Šaljite fakture, pratite troškove i automatizujte računovodstvo uz Akaunting. :get_started_url',
    'get_started'           => 'Početak',

];
