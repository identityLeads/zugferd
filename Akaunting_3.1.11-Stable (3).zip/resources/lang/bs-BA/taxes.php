<?php

return [

    'rate'                  => 'Stopa',
    'rate_percent'          => 'Stopa (%)',
    'normal'                => 'Normalno',
    'inclusive'             => 'Uključivo',
    'compound'              => 'Veza',
    'fixed'                 => 'Fiksno',
    'withholding'           => 'Zadržavajuće',
    'no_taxes'              => 'Bez poreza',
    'create_task'           => 'Kreirajte novi porez i uredite bilo kada u podešavanjima.',
    'new_tax'               => 'Novi porez',

    'form_description' => [
        'general'           => 'U cijenu artikla uračunat je uključeni porez. Složeni porez se obračunava povrh ostalih poreza. Fiksni porez se primjenjuje u iznosu, a ne u postotku.',
    ],

];
