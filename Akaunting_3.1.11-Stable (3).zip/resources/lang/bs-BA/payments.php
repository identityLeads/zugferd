<?php

return [

    'payment_made'      => 'Mod plaćanja',
    'paid_to'           => 'Plaćeno',
    'related_bill'      => 'Vezani računi',
    'create_payment'    => 'Kreiraj uplatu',

];
