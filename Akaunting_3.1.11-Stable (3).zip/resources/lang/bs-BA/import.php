<?php

return [

    'import'                => 'Uvezi',
    'title'                 => 'Uvoz :type',
    'limitations'           => 'Dozvoljeni tipovi fajlova: :extensions<br>Maksimalan broj redova: :row_limit',
    'sample_file'           => 'Mozete da <a target="_blank" href=":download_link"><strong>skinete</strong></a> primjer i popunite sa svojim podacima.',

];
