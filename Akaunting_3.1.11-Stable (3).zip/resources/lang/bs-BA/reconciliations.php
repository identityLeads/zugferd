<?php

return [

    'reconcile'             => 'Usaglasi',
    'unreconcile'           => 'Neusaglasi',
    'reconciled'            => 'Usaglašeno',
    'opening_balance'       => 'Početni saldo',
    'closing_balance'       => 'Završni saldo',
    'unreconciled'          => 'Nesaglašen',
    'transactions'          => 'Transakcije',
    'start_date'            => 'Početni datum',
    'end_date'              => 'Datum završetka',
    'cleared_amount'        => 'Očisti iznos',
    'deposit'               => 'Depozit',
    'withdrawal'            => 'Povlačenje',
    'reconciled_amount'     => 'Usaglašeno',
    'in_progress'           => 'U toku',
    'save_draft'            => 'Sačuvaj u pripremu',
    'irreconcilable'        => 'Nepomirljiv',

];
