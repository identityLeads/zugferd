<?php

return [

    'collapse'              => 'Skupi',

    'form_description' => [
        'general'           => 'Kategorija vam pomaže da klasifikujete svoje stavke, prihode, rashode i druge zapise.',
    ],

];
