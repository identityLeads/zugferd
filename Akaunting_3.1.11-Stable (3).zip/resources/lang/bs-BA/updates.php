<?php

return [

    'installed_version'     => 'Instalirana verzija',
    'latest_version'        => 'Posljednja verzija',
    'update'                => 'Ažuriraj na :version verziju',
    'changelog'             => 'Popis promjena',
    'check'                 => 'Provjera',
    'new_core'              => 'Dostupno je ažuriranje.',
    'latest_core'           => 'Čestitamo! Imate najnoviju verziju. Buduća sigurnosna ažuriranja primjenjivat će se automatski.',
    'success'               => 'Proces ažuriranja uspješno završen.',
    'error'                 => 'Proces ažuriranja nije uspio, molimo pokušajte ponovo.',

];
