<?php

return [

    'columns' => [
        'last_logged_in_at' => 'Posljednja prijava',
        'paid_at'           => 'Datum plaćanja',
        'started_at'        => 'Datum početka',
        'ended_at'          => 'Datum završetka',
        'billed_at'         => 'Datu računa',
        'due_at'            => 'Datum dospjeća',
        'invoiced_at'       => 'Datum fakture',
        'issued_at'         => 'Datum dospjeća',
        'symbol_first'      => 'Položaj simbola',
        'reconciled'        => 'Usaglašeno',
        'expense_account'   => 'Sa računa',
        'income_account'    => 'Na račun',
        'recurring'         => 'Ponavljajuće',
    ],

];
