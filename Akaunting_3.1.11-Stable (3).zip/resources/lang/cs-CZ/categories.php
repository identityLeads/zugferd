<?php

return [

    'collapse'              => 'Skrýt všechno',

    'form_description' => [
        'general'           => 'Kategorie vám pomůže klasifikovat vaše položky, příjmy, výdaje a další záznamy.',
    ],

];
