<?php

return [

    'previous'              => 'Anterior',
    'next'                  => 'Següent',
    'showing'               => '(:first-:last de :total)',
    'page'                  => 'per pàgina',
];
