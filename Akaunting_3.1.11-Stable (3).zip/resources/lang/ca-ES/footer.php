<?php

return [

    'version'               => 'Versió',
    'powered'               => 'Creat per Akaunting',
    'link'                  => 'https://akaunting.com',
    'software'              => 'Programari lliure de Facturació/Comptabilitat',
    'powered_by'            => 'Creat per',
    'tag_line'              => 'Envia factures, fes un seguiment de les despeses i automatitza la comptabilitat amb Akaunting. :get_started_url',
    'get_started'           => 'Comença',

];
