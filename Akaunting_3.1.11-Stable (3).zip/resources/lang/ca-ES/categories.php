<?php

return [

    'collapse'              => 'Replegar',

    'form_description' => [
        'general'           => 'Les categories us ajuden a classificar els vostres articles, ingressos, despeses i altres registres.',
    ],

];
