<?php

return [

    'payment_made'      => 'S\'ha fet el pagament',
    'paid_to'           => 'Pagat a',
    'related_bill'      => 'Factura relacionada',
    'create_payment'    => 'Crea pagament',

];
