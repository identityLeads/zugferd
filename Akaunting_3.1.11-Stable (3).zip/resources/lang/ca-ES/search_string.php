<?php

return [

    'columns' => [
        'last_logged_in_at' => 'Últim accés',
        'paid_at'           => 'Data de pagament',
        'started_at'        => 'Data d\'inici',
        'ended_at'          => 'Data de fi',
        'billed_at'         => 'Data de factura',
        'due_at'            => 'Data de venciment',
        'invoiced_at'       => 'Data de factura',
        'issued_at'         => 'Data de venciment',
        'symbol_first'      => 'Posició del caràcter',
        'reconciled'        => 'Concilia',
        'expense_account'   => 'Compte origen',
        'income_account'    => 'Compte destí',
        'recurring'         => 'Recurrent',
    ],

];
