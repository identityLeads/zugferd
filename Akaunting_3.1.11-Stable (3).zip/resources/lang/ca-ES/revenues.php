<?php

return [

    'revenue_received'      => 'Ingrés rebut',
    'paid_by'               => 'Pagat per',
    'related_invoice'       => 'Factura relacionada',
    'create_revenue'        => 'Crea ingrés',

];
