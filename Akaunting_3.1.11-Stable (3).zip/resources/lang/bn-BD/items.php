<?php

return [

    'sale_price'           => 'বিক্রয় মূল্য',
    'purchase_price'        => 'ক্রয়মূল্য',

];
