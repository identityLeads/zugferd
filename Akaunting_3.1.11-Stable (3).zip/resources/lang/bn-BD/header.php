<?php

return [

    'change_language'       => 'ভাষা পরিবর্তন',
    'last_login'            => 'সর্বশেষ লগইন :time',
    'notifications' => [
        'counter'           => '{0} কোন নোটিফিকেশন নেই |{1}  : count টি বিজ্ঞপ্তি |[2,*]  :count টি বিজ্ঞপ্তি',
        'overdue_invoices'  => '{1} :count টি সময়োত্তীর্ণ ইনভয়েস |[2,*] :count টি সময়োত্তীর্ণ ইনভয়েস |',
        'upcoming_bills'    => '{1} :count টি আসন্ন বিল|[2,*] :count টি আসন্ন বিল',
        'view_all'          => 'সবগুলো দেখুন'
    ],
    'docs_link'             => 'https://akaunting.com/docs',
    'support_link'          => 'https://akaunting.com/support',

];
