<?php

return [

    'account_name'          => 'অ্যাকাউন্টের নাম',
    'number'                => 'সংখ্যা',
    'opening_balance'       => 'শুরুর ব্যালেন্স',
    'current_balance'       => 'বর্তমান ব্যালেন্স',
    'bank_name'             => 'ব্যাংকের নাম',
    'bank_phone'            => 'ব্যাংকের ফোন নাম্বার',
    'bank_address'          => 'ব্যাংকের ঠিকানা',
    'default_account'       => 'ডিফল্ট একাউন্ট',
    'incoming'              => 'অন্তর্গামী',
    'outgoing'              => 'বহির্গামী',
    'see_performance'       => 'কর্মক্ষমতা প্রদর্শন',
    'create_report'         => 'একাউন্টের কর্মদক্ষতা প্রদর্শন বরাতে চাইলে আপনি আয় বনাম ব্যয় প্রতিবেদন তৈরি করে নিতে পারেন।',

];
