<?php

return [

    'previous'              => 'পূর্ববর্তী',
    'next'                  => 'পরবর্তী',
    'showing'               => 'মোট :total টি ভুক্তির মধ্যে :first থেকে :last  পর্যন্ত।',
    'page'                  => 'প্রতি পৃষ্ঠায় ।',
];
