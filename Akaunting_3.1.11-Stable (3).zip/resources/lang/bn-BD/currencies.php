<?php

return [

    'code'                  => 'কোড',
    'rate'                  => 'হার',
    'default'               => 'পূর্বনির্ধারিত মুদ্রা',
    'decimal_mark'          => 'দশমিক চিহ্ন',
    'thousands_separator'   => 'সহস্রাংক নির্দেশক',
    'precision'             => 'সুচারু',
    'symbol' => [
        'symbol'            => 'প্রতীক',
        'position'          => 'প্রতীকের অবস্থান',
        'before'            => 'মূল্যের পূর্বে',
        'after'             => 'মূল্যের  পরে',
    ]

];
