<?php

return [

    'version'               => 'Версия',
    'powered'               => 'С подкрепата на Akaunting',
    'link'                  => 'https://akaunting.com',
    'software'              => 'Безплатен счетоводен софтуер',
    'powered_by'            => 'С подкрепата на',
    'tag_line'              => 'Изпращайте фактури, проследявайте разходите и автоматизирайте счетоводството с Akaunting. :get_started_url',
    'get_started'           => 'Да започваме',

];
