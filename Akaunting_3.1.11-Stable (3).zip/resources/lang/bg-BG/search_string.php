<?php

return [

    'columns' => [
        'last_logged_in_at' => 'Последно влизане',
        'paid_at'           => 'Платено на',
        'started_at'        => 'Начална дата',
        'ended_at'          => 'Крайна дата',
        'billed_at'         => 'Дата фактура',
        'due_at'            => 'Падежна дата',
        'invoiced_at'       => 'Дата на фактура',
        'issued_at'         => 'Дата на издаване',
        'symbol_first'      => 'Символ позиция',
        'reconciled'        => 'Оспорен',
        'expense_account'   => 'От сметка',
        'income_account'    => 'Към сметка',
        'recurring'         => 'Повтарящи се',
    ],

];
