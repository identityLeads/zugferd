<?php

return [

    'columns' => [
        'last_logged_in_at' => 'آخر تسجيل دخول',
        'paid_at'           => 'تاريخ الدفع',
        'started_at'        => 'تاريخ البدء',
        'ended_at'          => 'تاريخ النهاية',
        'billed_at'         => 'تاريخ الفاتورة',
        'due_at'            => 'تاريخ الاستحقاق',
        'invoiced_at'       => 'تاريخ الفاتورة',
        'issued_at'         => 'تاريخ الإصدار',
        'symbol_first'      => 'موضع الرمز',
        'reconciled'        => 'تمت التسوية',
        'expense_account'   => 'من حساب',
        'income_account'    => 'إلى حساب',
        'recurring'         => 'متكرر',
    ],

];
