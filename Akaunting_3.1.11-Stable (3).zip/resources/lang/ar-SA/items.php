<?php

return [

    'sale_price'           => 'سعر البيع',
    'purchase_price'        => 'سعر الشراء',

];
