<?php

return [

    'recurring'             => 'متكرر',
    'every'                 => 'كل',
    'period'                => 'فترة',
    'times'                 => 'عدد المرات',
    'daily'                 => 'يومي',
    'weekly'                => 'أسبوعي',
    'monthly'               => 'شهري',
    'yearly'                => 'سنوي',
    'custom'                => 'مُخصّص',
    'days'                  => 'يوم (أيام)',
    'weeks'                 => 'أسبوع (أسابيع)',
    'months'                => 'شهر (أشهر)',
    'years'                 => 'سنة (سنوات)',
    'message'               => 'هذه :type متكررة و :type التالية سيتم إنشاؤها تلقائياً في تاريخ :date',

];
