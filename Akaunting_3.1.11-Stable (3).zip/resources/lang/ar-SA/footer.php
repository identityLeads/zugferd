<?php

return [

    'version'               => 'إصدار',
    'powered'               => 'بواسطة أكاونتينج',
    'link'                  => 'https://akaunting.com',
    'software'              => 'برنامج محاسبي مجاني',
    'powered_by'            => 'مدعوم من قبل',
    'tag_line'              => 'إرسال الفواتير، تتبع المصروفات، وأتمتة المحاسبة باستخدام Akaunting. :get_started_url',
    'get_started'           => 'إبدأ الآن',

];
