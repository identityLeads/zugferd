<?php

return [

    'from_account'          => 'من حساب',
    'from_account_rate'     => 'من تسعيرة حساب',
    'to_account'            => 'إلى حساب',
    'to_account_rate'       => 'إلى تسعيرة حساب',
    'details'               => 'تفاصيل|تفاصيل',

    'messages' => [
        'delete'            => ':from إلى :to (:amount)',
    ],

];
