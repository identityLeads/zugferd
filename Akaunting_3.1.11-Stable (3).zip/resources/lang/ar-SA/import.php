<?php

return [

    'import'                => 'استيراد',
    'title'                 => 'استيراد :type',
    'limitations'           => 'أنواع الملفات المسموح بها: :extensions<br>الحد الأقصى المسموح به: :row_limit',
    'sample_file'           => 'يمكنك <a target="_blank" href=":download_link"><strong>تنزيل</strong></a> ملف العينة وملء بياناتك.',

];
