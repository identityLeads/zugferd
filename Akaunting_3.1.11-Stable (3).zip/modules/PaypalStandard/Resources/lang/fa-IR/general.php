<?php

return [

    'name'              => 'PayPal استاندارد',
    'description'       => 'گزینه پرداخت استاندارد PayPal را فعال کنید',

    'form' => [
        'email'         => 'ایمیل',
        'mode'          => 'حالت',
        'debug'         => 'اشکال زدايي کردن',
        'transaction'   => 'تراکنش‌ها',
        'customer'      => 'نمایش به مشتری',
        'order'         => 'سفارش',
    ],

    'test_mode'         => 'هشدار: درگاه پرداخت در "حالت Sandbox" است. حساب شما شارژ نخواهد شد.',
    //'description'       => 'Pay with PAYPAL',

];
