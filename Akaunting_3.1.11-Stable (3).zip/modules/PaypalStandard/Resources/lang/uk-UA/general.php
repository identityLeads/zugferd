<?php

return [

    'name'              => 'PayPal Стандартний',
    'description'       => 'Включити стандартний варіант оплати PayPal',

    'form' => [
        'email'         => 'E-mail',
        'mode'          => 'Режим',
        'debug'         => 'Налагодження',
        'transaction'   => 'Транзакції',
        'customer'      => 'Показати Клієнту',
        'order'         => 'Замовлення',
    ],

    'test_mode'         => 'Увага: Платіжний шлюз у тестовому режимі. Гроші з вашого рахунку не будуть списані.',
    //'description'       => 'Pay with PAYPAL',

];
