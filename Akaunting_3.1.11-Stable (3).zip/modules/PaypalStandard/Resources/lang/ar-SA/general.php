<?php

return [

    'name'              => 'معيار الباي بال',
    'description'       => 'تمكين خيار الدفع القياسي لـ باي بال',

    'form' => [
        'email'         => 'البريد الإلكتروني',
        'mode'          => 'نمط',
        'debug'         => 'تصحيح الأخطاء',
        'transaction'   => 'المعاملات',
        'customer'      => 'إظهار للعميل',
        'order'         => 'طلب',
    ],

    'test_mode'         => 'تحذير: بوابة الدفع في وضع "Sandbox". لن يتم احتساب مبالغ على حسابك.',
    //'description'       => 'Pay with PAYPAL',

];
