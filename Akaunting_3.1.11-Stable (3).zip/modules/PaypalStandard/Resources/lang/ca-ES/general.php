<?php

return [

    'name'              => 'PayPal estàndard',
    'description'       => 'Activa el pagament estàndard amb PayPal',

    'form' => [
        'email'         => 'Correu electrònic',
        'mode'          => 'Mode',
        'debug'         => 'Depura',
        'transaction'   => 'Transacció',
        'customer'      => 'Mostra al client',
        'order'         => 'Comanda',
    ],

    'test_mode'         => 'Avís: La passarel·la de pagament està en \'mode de proves\'. El teu compte no es veurà afectat per l\'acció.',
    //'description'       => 'Pay with PAYPAL',

];
