<?php

return [

    'name'              => 'Offline Payments',
    'description'       => 'Krijoni mundësi të pakufizuara pagese për përdorim të administratorit',

    'add_new'           => 'Shto të Re',
    'edit'              => 'Redaktoni: :method',

    'form' => [
        'code'          => 'Kodi',
        'customer'      => 'Trego tek Klienti',
        'order'         => 'Porosi'
    ],

    'methods'           => 'Metodë|Metodat',

    'payment_gateways'  => 'Metodat e Pagesës Offline',

];
