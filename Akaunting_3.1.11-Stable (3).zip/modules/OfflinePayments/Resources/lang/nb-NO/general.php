<?php

return [

    'name'              => 'Offline betalinger',
    'description'       => 'Lag ubegrensede betalingsalternativer for administrasjonsbruk',

    'add_new'           => 'Legg til ny',
    'edit'              => 'Rediger:: method',

    'form' => [
        'code'          => 'Kode',
        'customer'      => 'Vis til kunde',
        'order'         => 'Rekkefølge'
    ],

    'methods'           => 'Metode|Metoder',

    'payment_gateways'  => 'Offline betalingsmetoder',

];
