<?php

return [

    'name'              => 'Pembayaran Offline',
    'description'       => 'Buat opsi pembayaran tak terbatas untuk admin gunakan',

    'add_new'           => 'Tambah Baru',
    'edit'              => 'Edit:: metode',

    'form' => [
        'code'          => 'Kode',
        'customer'      => 'Tunjukkan kepada Pelanggan',
        'order'         => 'Pesanan'
    ],

    'methods'           => 'Metode|Metode',

    'payment_gateways'  => 'Metode Pembayaran Offline',

];
