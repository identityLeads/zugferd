<?php

return [

    'name'              => 'پرداخت های آفلاین',
    'description'       => 'ساخت گزینه پرداخت نامحدود برای استفاده مدیر',

    'add_new'           => 'افزودن جدید',
    'edit'              => 'ویرایش: :method',

    'form' => [
        'code'          => 'کد',
        'customer'      => 'نمایش به مشتری',
        'order'         => 'سفارش'
    ],

    'methods'           => 'روش|روش ها',

    'payment_gateways'  => 'روش های پرداخت آفلاین',

];
