<?php

return [

    'name'      =>  'Akaunting',

    'code'      =>  'Speed',

    'major'     =>  '3',

    'minor'     =>  '1',

    'patch'     =>  '11',

    'build'     =>  '',

    'status'    =>  'Stable',

    'date'      =>  '07-August-2024',

    'time'      =>  '22:00',

    'zone'      =>  'GMT +3',

];
