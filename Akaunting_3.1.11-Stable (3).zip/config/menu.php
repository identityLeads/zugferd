<?php

return [

    'styles' => [
        'tailwind' => \App\View\Presenters\Menu::class,
    ],

    'home_urls' => [
        '/',
        'portal',
    ],

    'ordering' => true,

];
