<?php

return [

    'proxies' => '*',

];
